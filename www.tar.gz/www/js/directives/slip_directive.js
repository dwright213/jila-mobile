(function() {
  angular.module('app').directive("slip", function() {
    return {
      restrict: "A",
      require: '?ngModel',
      link: function($scope, $element, attrs, ngModel) {
        var list;
        list = $element[0];
        list.addEventListener('slip:beforewait', function(e) {
          return e.preventDefault();
        });
        list.addEventListener('slip:reorder', function(e) {
          e.target.parentNode.insertBefore(e.target, e.detail.insertBefore);
          return $scope.$apply(function() {
            return ngModel.$modelValue.splice(e.detail.spliceIndex, 0, ngModel.$modelValue.splice(e.detail.originalIndex, 1)[0]);
          });
        });
        return new Slip(list);
      }
    };
  });

}).call(this);
