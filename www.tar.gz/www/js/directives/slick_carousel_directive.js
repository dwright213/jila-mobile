(function() {
  angular.module('app').directive("slickCarousel", function() {
    return {
      restrict: "A",
      link: function($scope, $element, attrs) {
        $scope.content = $element.slick({
          arrows: false,
          infinite: false,
          onAfterChange: function(state) {
            return $scope.$apply(function() {
              $scope.indexChanged(state.currentSlide);
            });
          }
        });
        return setTimeout(function() {
          var newHeight;
          newHeight = $(window).height() - $('.navigation').height() - $('.tab-headers').height();
          return $element.find('.tab-page').height(newHeight);
        });
      }
    };
  });

}).call(this);
