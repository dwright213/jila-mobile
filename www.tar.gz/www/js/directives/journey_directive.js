(function() {
  angular.module('app').directive("journey", [
    '$timeout', function($timeout) {
      return {
        restrict: "A",
        link: function($scope, $element, attrs) {
          return $scope.$watch('categories', function() {
            var angle, children, distance, dx, dy, height, i, results, track, windowWidth;
            windowWidth = $(window).width();
            height = 100;
            children = $element.children();
            $element.height(children.length * height);
            children.each(function(idx, c) {
              var left, pattern, top, track, xOffset, yOffset;
              c = $(c);
              pattern = idx % 6;
              xOffset = (function() {
                switch (pattern) {
                  case 0:
                    return 10;
                  case 1:
                    return 45;
                  case 2:
                    return 70;
                  case 3:
                    return 35;
                  case 4:
                    return 15;
                  case 5:
                    return 55;
                }
              })();
              left = xOffset / 100 * windowWidth;
              c.css('left', left + "px");
              yOffset = (function() {
                switch (pattern) {
                  case 0:
                    return 8;
                  case 1:
                    return 0;
                  case 2:
                    return 5;
                  case 3:
                    return -25;
                  case 4:
                    return 2;
                  case 5:
                    return 0;
                }
              })();
              top = height * idx + yOffset + height / 2;
              c.css('top', top + "px");
              track = c.find('.track');
              top = left = 0;
              switch (pattern) {
                case 0:
                  left = 90;
                  break;
                case 1:
                  top = 45;
                  left = 45;
                  break;
                case 2:
                  left = -45;
                  break;
                case 3:
                  top = 45;
                  break;
                case 4:
                  left = 90;
                  break;
                case 5:
                  left = -90;
              }
              track.css('top', top + "px");
              return track.css('left', left + "px");
            });
            i = 0;
            results = [];
            while (i < children.length - 1) {
              track = $(children[i]).find('.track');
              dx = children[i].offsetLeft - children[i + 1].offsetLeft;
              dy = children[i].offsetTop - children[i + 1].offsetTop;
              angle = Math.atan2(dy, dx) * 180 / Math.PI + 270;
              track.css('transform', "rotate(" + angle + "deg)");
              distance = Math.sqrt(Math.pow(dx, 2) + Math.pow(dy, 2));
              track.height(distance);
              results.push(i++);
            }
            return results;
          });
        }
      };
    }
  ]);

}).call(this);
