(function() {
  var Platform;

  window.isWebView = document.URL.indexOf('http://') === -1 ? true : false;

  Platform = (function() {
    function Platform() {
      this.readyFlag = false;
      this.readyCallbacks = [];
      if (window.isWebView) {
        document.addEventListener('deviceready', (function(_this) {
          return function() {
            _this.readyFlag = true;
            _this.readyCallbacks.forEach(function(cb) {
              return cb();
            });
            return _this.readyCallbacks = [];
          };
        })(this));
      } else {
        this.readyFlag = true;
      }
    }

    Platform.prototype.isReady = function(callback) {
      if (this.readyFlag) {
        return callback();
      } else {
        return this.readyCallbacks.push(callback);
      }
    };

    return Platform;

  })();

  window.Platform = new Platform();

}).call(this);
