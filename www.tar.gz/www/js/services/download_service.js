(function() {
  var Service,
    bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

  Service = (function() {
    function Service($http, $q, categoryService, entryService, fileService) {
      this.$http = $http;
      this.$q = $q;
      this.categoryService = categoryService;
      this.entryService = entryService;
      this.fileService = fileService;
      this.imageTypesFor = bind(this.imageTypesFor, this);
      this.saveAsset = bind(this.saveAsset, this);
      this.saveAssetsForEntry = bind(this.saveAssetsForEntry, this);
      this.saveAssetsForCategory = bind(this.saveAssetsForCategory, this);
    }

    Service.prototype.saveAssetsForCategory = function(category) {
      return this.imageTypesFor(category).forEach((function(_this) {
        return function(imageType) {
          if (category.images[imageType] && category.images[imageType].indexOf('http') === 0) {
            return _this.saveAsset(category.images[imageType]).then(function(dataUri) {
              category.images[imageType] = dataUri;
              return _this.categoryService.save(category);
            });
          }
        };
      })(this));
    };

    Service.prototype.saveAssetsForEntry = function(entry) {
      this.imageTypesFor(entry).forEach((function(_this) {
        return function(imageType) {
          if (entry.images[imageType] && entry.images[imageType].indexOf('http') === 0) {
            return _this.saveAsset(entry.images[imageType]).then(function(dataUri) {
              entry.images[imageType] = dataUri;
              return _this.entryService.save(entry);
            });
          }
        };
      })(this));
      if (entry.audio && entry.audio.indexOf('http') === 0) {
        return this.saveAsset(entry.audio).then((function(_this) {
          return function(dataUri) {
            entry.audio = "" + dataUri;
            return _this.entryService.save(entry);
          };
        })(this));
      }
    };

    Service.prototype.saveAsset = function(url) {
      var deferred, handleError;
      deferred = this.$q.defer();
      handleError = function() {
        console.log("Error saving asset for " + url);
        return deferred.reject();
      };
      this.fileService.existingFor(url).then(function(existingUri) {
        return deferred.resolve(existingUri);
      }, (function(_this) {
        return function() {
          return _this.$http.get(url, {
            responseType: 'arraybuffer'
          }).then(function(res) {
            var blob;
            blob = new Blob([res.data], {
              type: 'text/plain'
            });
            return _this.fileService.store(blob, url).then(function(uri) {
              return deferred.resolve(uri);
            }, handleError);
          }, handleError);
        };
      })(this));
      return deferred.promise;
    };

    Service.prototype.imageTypesFor = function(model) {
      var imageType, imageTypes;
      imageTypes = [];
      for (imageType in model.images) {
        imageTypes.push(imageType);
      }
      return imageTypes;
    };

    return Service;

  })();

  angular.module('app').service('downloadService', ['$http', '$q', 'categoryService', 'entryService', 'fileService', Service]);

}).call(this);
