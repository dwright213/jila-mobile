(function() {
  var Service,
    bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

  Service = (function() {
    function Service($q) {
      this.$q = $q;
      this.store = bind(this.store, this);
    }

    Service.prototype.existingFor = function(url) {
      var deferred;
      deferred = this.$q.defer();
      deferred.resolve(url);
      return deferred.promise;
    };

    Service.prototype.store = function(blob, url) {
      var deferred, fileReader;
      deferred = this.$q.defer();
      fileReader = new FileReader();
      fileReader.onload = function(e) {
        return deferred.resolve(e.target.result);
      };
      return deferred.promise;
    };

    return Service;

  })();

  if (!window.isWebView) {
    angular.module('app').service('fileService', ['$q', Service]);
  }

}).call(this);
