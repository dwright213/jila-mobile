(function() {
  var Service,
    bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

  Service = (function() {
    function Service($q, $analytics) {
      this.$q = $q;
      this.$analytics = $analytics;
      this.clear = bind(this.clear, this);
      this.search_for = bind(this.search_for, this);
      this.save = bind(this.save, this);
      this.entries_for_letter = bind(this.entries_for_letter, this);
      this.all = bind(this.all, this);
      this.get = bind(this.get, this);
      this.entries_for = bind(this.entries_for, this);
    }

    Service.prototype.entries_for = function(categoryId) {
      var deferred;
      deferred = this.$q.defer();
      Lawnchair({
        name: 'entries',
        adapter: 'dom'
      }, (function(_this) {
        return function(store) {
          return store.where("_.contains(record.value.categories, " + categoryId + ")", function(entries) {
            return deferred.resolve(entries.map(function(e) {
              return e.value;
            }));
          });
        };
      })(this));
      return deferred.promise;
    };

    Service.prototype.get = function(entryId) {
      var deferred;
      deferred = this.$q.defer();
      Lawnchair({
        name: 'entries',
        adapter: 'dom'
      }, function(store) {
        return store.get(entryId, function(entry) {
          return deferred.resolve(entry.value);
        });
      });
      return deferred.promise;
    };

    Service.prototype.all = function() {
      var deferred;
      deferred = this.$q.defer();
      Lawnchair({
        name: 'entries',
        adapter: 'dom'
      }, function(store) {
        return store.all(function(entries) {
          return deferred.resolve(entries.map(function(e) {
            return e.value;
          }));
        });
      });
      return deferred.promise;
    };

    Service.prototype.entries_for_letter = function(letter) {
      var deferred;
      deferred = this.$q.defer();
      Lawnchair({
        name: 'entries',
        adapter: 'dom'
      }, function(store) {
        return store.all(function(entry_data) {
          var entries;
          entries = entry_data.map(function(e) {
            return e.value;
          });
          return deferred.resolve(entries.filter(function(e) {
            return e.entry_word[0] === letter;
          }));
        });
      });
      return deferred.promise;
    };

    Service.prototype.save = function(entry) {
      return Lawnchair({
        name: 'entries',
        adapter: 'dom'
      }, function(store) {
        return store.save({
          key: entry.id,
          value: entry
        });
      });
    };

    Service.prototype.search_for = function(query) {
      var deferred;
      deferred = this.$q.defer();
      Lawnchair({
        name: 'entries',
        adapter: 'dom'
      }, (function(_this) {
        return function(store) {
          return store.where("record.value.translation.toLowerCase().indexOf('" + (query.toLowerCase()) + "') !== -1", function(entries) {
            if (entries.length === 0) {
              _this.$analytics.eventTrack('SearchNotFound', {
                category: 'SearchNotFound',
                label: query
              });
            }
            return deferred.resolve(entries.map(function(e) {
              return e.value;
            }));
          });
        };
      })(this));
      return deferred.promise;
    };

    Service.prototype.clear = function() {
      return Lawnchair({
        name: 'entries',
        adapter: 'dom'
      }, function(store) {
        return store.nuke();
      });
    };

    return Service;

  })();

  angular.module('app').service('entryService', ['$q', '$analytics', Service]);

}).call(this);
