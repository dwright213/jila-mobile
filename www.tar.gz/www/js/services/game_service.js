(function() {
  var Service,
    bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

  Service = (function() {
    function Service($location, $q, categoryService, GAMES_PER_ROUND, LIVES_PER_ROUND) {
      this.$location = $location;
      this.$q = $q;
      this.categoryService = categoryService;
      this.GAMES_PER_ROUND = GAMES_PER_ROUND;
      this.LIVES_PER_ROUND = LIVES_PER_ROUND;
      this.setupGamesFor = bind(this.setupGamesFor, this);
      this.generateGamesListFor = bind(this.generateGamesListFor, this);
      this.gameStatus = bind(this.gameStatus, this);
      this.initialiseStatus = bind(this.initialiseStatus, this);
      this.fail = bind(this.fail, this);
      this.success = bind(this.success, this);
      this.gameInProgress = false;
      this.livesRemaining = 0;
    }

    Service.prototype.success = function() {
      this.lastRoundSuccessful = true;
      return this.gameStatus();
    };

    Service.prototype.fail = function() {
      this.livesRemaining--;
      if (this.livesRemaining === 0) {
        this.gameInProgress = false;
      }
      this.lastRoundSuccessful = false;
      return this.gameStatus();
    };

    Service.prototype.initialiseStatus = function() {
      this.livesLost = 0;
      this.livesRemaining = this.LIVES_PER_ROUND;
      this.gameInProgress = true;
      return this.lastRoundSuccessful = true;
    };

    Service.prototype.gameStatus = function() {
      return {
        livesLost: this.LIVES_PER_ROUND - this.livesRemaining,
        livesRemaining: this.livesRemaining,
        gameInProgress: this.gameInProgress,
        lastRoundSuccessful: this.lastRoundSuccessful
      };
    };

    Service.prototype.generateGamesListFor = function(categoryId) {
      var deferred;
      deferred = this.$q.defer();
      this.categoryService.get(categoryId).then((function(_this) {
        return function(category) {
          var audioGames, games, i, numGamesRemaining, pictureGames, randomGames, results, wordGames;
          wordGames = [6, 7];
          audioGames = [1, 2, 5, 8];
          pictureGames = [3, 4, 9];
          games = wordGames;
          if (category.games.audio) {
            games = games.concat(audioGames);
          }
          if (category.games.image) {
            games = games.concat(pictureGames);
          }
          numGamesRemaining = _this.GAMES_PER_ROUND - games.length;
          randomGames = (function() {
            results = [];
            for (var i = 1; 1 <= numGamesRemaining ? i <= numGamesRemaining : i >= numGamesRemaining; 1 <= numGamesRemaining ? i++ : i--){ results.push(i); }
            return results;
          }).apply(this).map(function(g) {
            var randomIndex;
            randomIndex = Math.floor(Math.random() * (games.length - 1));
            return games[randomIndex];
          });
          games = games.concat(randomGames);
          return deferred.resolve(_.sample(games, _this.GAMES_PER_ROUND));
        };
      })(this));
      return deferred.promise;
    };

    Service.prototype.setupGamesFor = function(categoryId) {
      return this.generateGamesListFor(categoryId).then((function(_this) {
        return function(games) {
          var first_game;
          _this.initialiseStatus();
          first_game = games.pop();
          return _this.$location.path("/games/" + categoryId + "/" + first_game).search("games=" + (JSON.stringify(games)));
        };
      })(this));
    };

    return Service;

  })();

  angular.module('app').service('gameService', ['$location', '$q', 'categoryService', 'GAMES_PER_ROUND', 'LIVES_PER_ROUND', Service]);

}).call(this);
