(function() {
  var Service,
    bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

  Service = (function() {
    function Service($q) {
      this.$q = $q;
      this.store = bind(this.store, this);
      this.all = bind(this.all, this);
    }

    Service.prototype.all = function() {
      var deferred, storedCredits;
      deferred = this.$q.defer();
      storedCredits = window.localStorage['imageCredits'];
      if (storedCredits) {
        deferred.resolve(JSON.parse(storedCredits));
      }
      return deferred.promise;
    };

    Service.prototype.store = function(imageCredits) {
      window.localStorage['imageCredits'] = JSON.stringify(imageCredits);
    };

    return Service;

  })();

  angular.module('app').service('imageCreditService', ['$q', Service]);

}).call(this);
