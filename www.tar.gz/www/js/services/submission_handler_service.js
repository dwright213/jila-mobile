(function() {
  var Service,
    bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

  Service = (function() {
    function Service($location, gameService, $analytics, i18nService) {
      this.$location = $location;
      this.gameService = gameService;
      this.$analytics = $analytics;
      this.i18nService = i18nService;
      this.handleSubmissionFor = bind(this.handleSubmissionFor, this);
    }

    Service.prototype.handleSubmissionFor = function(controller) {
      var correctImage, explanation, gameStatus, resultTitle, status;
      if (controller.hasValidAnswer()) {
        resultTitle = this.i18nService.get('roundTitleSuccess');
        explanation = this.i18nService.get('roundMessageSuccess');
        gameStatus = this.gameService.success();
      } else if (controller.allowsAcceptableAnswer() && controller.hasAcceptableAnswer()) {
        resultTitle = this.i18nService.get('roundTitleSuccess');
        explanation = this.i18nService.get('roundMessageSuccessWithWarning');
        gameStatus = this.gameService.success();
      } else {
        resultTitle = this.i18nService.get('roundTitleFailure');
        explanation = this.i18nService.get('roundMessageFailure');
        gameStatus = this.gameService.fail();
        if (controller.answerImage) {
          correctImage = controller.answerImage();
        } else {
          explanation = explanation + "'" + controller.$scope.answer.label + "'";
        }
        this.$analytics.eventTrack('IncorrectAnswer', {
          category: 'IncorrectAnswer',
          label: controller.$scope.answer.label
        });
      }
      status = {
        resultTitle: resultTitle,
        explanation: explanation,
        correctImage: correctImage,
        gameStatus: gameStatus
      };
      return this.$location.path("/games/" + (controller.categoryId()) + "/result").search("status=" + (JSON.stringify(status)) + "&games=" + (this.$location.search()['games']));
    };

    return Service;

  })();

  angular.module('app').service('submissionHandlerService', ['$location', 'gameService', '$analytics', 'i18nService', Service]);

}).call(this);
