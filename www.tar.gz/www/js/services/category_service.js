(function() {
  var Service,
    bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

  Service = (function() {
    function Service($q) {
      this.$q = $q;
      this.clear = bind(this.clear, this);
      this.save = bind(this.save, this);
      this.get = bind(this.get, this);
      this.all = bind(this.all, this);
    }

    Service.prototype.all = function() {
      var deferred;
      deferred = this.$q.defer();
      Lawnchair({
        name: 'categories',
        adapter: 'dom'
      }, function(store) {
        return store.all(function(categories) {
          return deferred.resolve(categories.map(function(e) {
            return e.value;
          }));
        });
      });
      return deferred.promise;
    };

    Service.prototype.get = function(categoryId) {
      var deferred;
      deferred = this.$q.defer();
      Lawnchair({
        name: 'categories',
        adapter: 'dom'
      }, function(store) {
        return store.get(categoryId, function(category) {
          return deferred.resolve(category.value);
        });
      });
      return deferred.promise;
    };

    Service.prototype.save = function(category) {
      return Lawnchair({
        name: 'categories',
        adapter: 'dom'
      }, function(store) {
        return store.save({
          key: category.id,
          value: category
        });
      });
    };

    Service.prototype.clear = function() {
      return Lawnchair({
        name: 'categories',
        adapter: 'dom'
      }, function(store) {
        return store.nuke();
      });
    };

    return Service;

  })();

  angular.module('app').service('categoryService', ['$q', Service]);

}).call(this);
