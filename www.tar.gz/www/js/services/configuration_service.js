(function() {
  var Service,
    bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

  Service = (function() {
    function Service($q) {
      this.$q = $q;
      this.initialSyncCompleted = bind(this.initialSyncCompleted, this);
      this.initialSyncComplete = bind(this.initialSyncComplete, this);
    }

    Service.prototype.initialSyncComplete = function() {
      if (window.localStorage['initialSyncComplete']) {
        return true;
      } else {
        return false;
      }
    };

    Service.prototype.initialSyncCompleted = function() {
      return window.localStorage['initialSyncComplete'] = true;
    };

    return Service;

  })();

  angular.module('app').service('configurationService', ['$q', Service]);

}).call(this);
