(function() {
  var Service,
    bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

  Service = (function() {
    function Service($http, $q, BACKEND_URL, configurationService, categoryService, entryService, imageCreditService, downloadService) {
      this.$http = $http;
      this.$q = $q;
      this.BACKEND_URL = BACKEND_URL;
      this.configurationService = configurationService;
      this.categoryService = categoryService;
      this.entryService = entryService;
      this.imageCreditService = imageCreditService;
      this.downloadService = downloadService;
      this.refresh = bind(this.refresh, this);
    }

    Service.prototype.refresh = function() {
      var deferred;
      deferred = this.$q.defer();
      this.$http.get(this.BACKEND_URL + "/api/sync/all").then((function(_this) {
        return function(res) {
          _this.categoryService.clear();
          _this.entryService.clear();
          res.data.categories.forEach(function(c) {
            var imageType;
            for (imageType in c.images) {
              if (!c.images[imageType]) {
                c.images[imageType] = "img/missing-category.png";
              }
            }
            _this.categoryService.save(c);
            return _this.downloadService.saveAssetsForCategory(c);
          });
          res.data.entries.forEach(function(e) {
            _this.entryService.save(e);
            return _this.downloadService.saveAssetsForEntry(e);
          });
          _this.imageCreditService.store(res.data.image_credits);
          _this.configurationService.initialSyncCompleted();
          return deferred.resolve();
        };
      })(this), (function(_this) {
        return function(err) {
          return deferred.reject();
        };
      })(this));
      return deferred.promise;
    };

    return Service;

  })();

  angular.module('app').service('syncService', ['$http', '$q', 'BACKEND_URL', 'configurationService', 'categoryService', 'entryService', 'imageCreditService', 'downloadService', Service]);

}).call(this);
