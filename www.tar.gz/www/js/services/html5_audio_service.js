(function() {
  var Service,
    bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

  Service = (function() {
    function Service() {
      this.stop = bind(this.stop, this);
      this.play = bind(this.play, this);
      this.player = $('.player');
      this.player.jPlayer({
        loadeddata: (function(_this) {
          return function(event) {};
        })(this),
        timeupdate: (function(_this) {
          return function(event) {};
        })(this),
        ended: (function(_this) {
          return function(event) {};
        })(this)
      });
    }

    Service.prototype.load = function(file) {
      console.log("Loading " + file);
      return this.player.jPlayer('stop').jPlayer('setMedia', {
        mp3: file,
        m4a: file
      });
    };

    Service.prototype.play = function(file) {
      this.load(file);
      console.log("Playing " + file);
      return this.player.jPlayer('play');
    };

    Service.prototype.stop = function() {
      return this.player.jPlayer('stop');
    };

    return Service;

  })();

  if (!window.isWebView) {
    angular.module('app').service('audioService', [Service]);
  }

}).call(this);
