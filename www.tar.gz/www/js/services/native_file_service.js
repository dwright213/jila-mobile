(function() {
  var Service,
    bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

  Service = (function() {
    function Service($q) {
      this.$q = $q;
      this.store = bind(this.store, this);
      this.existingFor = bind(this.existingFor, this);
    }

    Service.prototype.filenameFor = function(url) {
      return "" + (url.hashCode());
    };

    Service.prototype.existingFor = function(url) {
      var checkFilePresence, deferred, fileExists, handleError;
      deferred = this.$q.defer();
      handleError = function() {
        return deferred.reject();
      };
      fileExists = function(entry) {
        console.log("Using existing file for " + url + " at " + (entry.toInternalURL()));
        return deferred.resolve(entry.toInternalURL());
      };
      checkFilePresence = (function(_this) {
        return function(fs) {
          return fs.root.getFile('jila/' + _this.filenameFor(url), {
            create: false
          }, fileExists, handleError);
        };
      })(this);
      window.requestFileSystem(LocalFileSystem.PERSISTENT, 0, checkFilePresence, handleError);
      return deferred.promise;
    };

    Service.prototype.store = function(blob, url) {
      var deferred, gotDirectoryEntry, gotFileEntry, gotFileSystem, handleError;
      deferred = this.$q.defer();
      handleError = function() {
        console.log("Error writing file for " + url);
        return deferred.reject();
      };
      gotFileSystem = (function(_this) {
        return function(fs) {
          return fs.root.getDirectory('jila', {
            create: true
          }, gotDirectoryEntry, handleError);
        };
      })(this);
      gotDirectoryEntry = (function(_this) {
        return function(dir) {
          dir.setMetadata((function() {}), handleError, {
            "com.apple.MobileBackup": 1
          });
          return dir.getFile(_this.filenameFor(url), {
            create: true
          }, gotFileEntry, handleError);
        };
      })(this);
      gotFileEntry = function(entry) {
        return entry.createWriter(function(writer) {
          writer.onwriteend = function(e) {
            console.log("Saving " + url + " to " + (entry.toInternalURL()));
            return deferred.resolve(entry.toInternalURL());
          };
          writer.onerror = handleError;
          return writer.write(blob);
        });
      };
      window.requestFileSystem(LocalFileSystem.PERSISTENT, 0, gotFileSystem, handleError);
      return deferred.promise;
    };

    return Service;

  })();

  if (window.isWebView) {
    angular.module('app').service('fileService', ['$q', Service]);
  }

}).call(this);
