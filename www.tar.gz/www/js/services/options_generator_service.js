(function() {
  var Service,
    bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

  Service = (function() {
    function Service(entryService, $q) {
      this.entryService = entryService;
      this.$q = $q;
      this.generateOptionsFor = bind(this.generateOptionsFor, this);
    }

    Service.prototype.generateOptionsFor = function(controller, categoryId) {
      var deferred;
      deferred = this.$q.defer();
      this.entryService.entries_for(categoryId).then(function(allOptions) {
        var displayOptions, options, validOptions;
        validOptions = controller.validOptionsFrom(allOptions);
        displayOptions = controller.displayOptions(validOptions);
        options = _.sample(displayOptions, controller.numOptionsRequired());
        deferred.resolve({
          answer: options[_.random(0, options.length - 1)],
          options: options
        });
      });
      return deferred.promise;
    };

    return Service;

  })();

  angular.module('app').service('optionsGeneratorService', ['entryService', '$q', Service]);

}).call(this);
