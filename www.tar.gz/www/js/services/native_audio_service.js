(function() {
  var Service,
    bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

  Service = (function() {
    function Service() {
      this.stop = bind(this.stop, this);
      this.play = bind(this.play, this);
      this.load = bind(this.load, this);
    }

    Service.prototype.load = function(file) {
      console.log("Loading " + file);
      if (this.media) {
        this.media.stop();
      }
      if (this.media) {
        this.media.release();
      }
      this.media = new Media(file, null, function(e) {
        return console.log(e);
      });
    };

    Service.prototype.play = function(file) {
      console.log("Playing " + file);
      this.load(file);
      return this.media.play();
    };

    Service.prototype.stop = function() {
      if (this.media) {
        this.media.stop();
      }
      if (this.media) {
        return this.media.release();
      }
    };

    return Service;

  })();

  if (window.isWebView) {
    angular.module('app').service('audioService', [Service]);
  }

}).call(this);
