(function() {
  if (typeof String.prototype.hashCode === 'undefined') {
    String.prototype.hashCode = function() {
      var chr, hash, i, len;
      hash = 0;
      i = void 0;
      chr = void 0;
      len = void 0;
      if (this.length === 0) {
        return hash;
      }
      i = 0;
      len = this.length;
      while (i < len) {
        chr = this.charCodeAt(i);
        hash = ((hash << 5) - hash) + chr;
        hash |= 0;
        i++;
      }
      return hash;
    };
  }

  if (typeof String.prototype.trim === 'undefined') {
    String.prototype.trim = function() {
      return String(this).replace(/^\s+|\s+$/g, '');
    };
  }

  if (typeof String.prototype.isPhrase === 'undefined') {
    String.prototype.isPhrase = function() {
      return this.split(' ').length > 1;
    };
  }

  if (typeof String.prototype.onlyAlphanumeric === 'undefined') {
    String.prototype.onlyAlphanumeric = function() {
      return this.replace(/\W+/g, '');
    };
  }

  if (typeof String.prototype.sanitize === 'undefined') {
    String.prototype.sanitize = function() {
      return this.trim().toLowerCase().replace(/\s+/g, '').onlyAlphanumeric();
    };
  }

  if (typeof String.prototype.splitIntoSegmentsOf === 'undefined') {
    String.prototype.splitIntoSegmentsOf = function(charactersPerSegment) {
      return this.match(RegExp(".{1," + charactersPerSegment + "}", 'g'));
    };
  }

  if (typeof String.prototype.levenshteinDistance === 'undefined') {
    String.prototype.levenshteinDistance = function(toCompare) {
      var i, j, matrix;
      if (this.length === 0) {
        return toCompare.length;
      }
      if (toCompare.length === 0) {
        return this.length;
      }
      matrix = [];
      i = void 0;
      i = 0;
      while (i <= toCompare.length) {
        matrix[i] = [i];
        i++;
      }
      j = void 0;
      j = 0;
      while (j <= this.length) {
        matrix[0][j] = j;
        j++;
      }
      i = 1;
      while (i <= toCompare.length) {
        j = 1;
        while (j <= this.length) {
          if (toCompare.charAt(i - 1) === this.charAt(j - 1)) {
            matrix[i][j] = matrix[i - 1][j - 1];
          } else {
            matrix[i][j] = Math.min(matrix[i - 1][j - 1] + 1, Math.min(matrix[i][j - 1] + 1, matrix[i - 1][j] + 1));
          }
          j++;
        }
        i++;
      }
      return matrix[toCompare.length][this.length];
    };
  }

}).call(this);
