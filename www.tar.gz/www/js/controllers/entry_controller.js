(function() {
  var Controller;

  Controller = (function() {
    function Controller($scope, $routeParams, entryService, audioService, $rootScope) {
      $rootScope.$emit('navigationConfig', {
        labelForTitle: "",
        backAction: function() {
          window.history.back();
        }
      });
      $scope.entry = {};
      entryService.get($routeParams.entryId).then((function(_this) {
        return function(entry) {
          $scope.entry = entry;
          $scope.formattedDescription = marked(entry.description);
          return $rootScope.$emit('navigationConfig', {
            labelForTitle: entry.entry_word
          });
        };
      })(this));
      $scope.listen = (function(_this) {
        return function() {
          if ($scope.entry) {
            audioService.play($scope.entry.audio);
          }
        };
      })(this);
    }

    return Controller;

  })();

  angular.module('app').controller('entryController', ['$scope', '$routeParams', 'entryService', 'audioService', '$rootScope', Controller]);

}).call(this);
