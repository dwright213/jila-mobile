(function() {
  var Controller;

  Controller = (function() {
    function Controller($scope, $rootScope, $location, entryService, i18nService) {
      $rootScope.$emit('navigationConfig', {
        labelForTitle: i18nService.get('dictionaryTitle'),
        backAction: function() {
          return $location.path('/home');
        }
      });
      entryService.all().then((function(_this) {
        return function(entries) {
          var first_letters;
          first_letters = _.map(entries, function(entry) {
            return entry.entry_word[0].toUpperCase();
          });
          return $scope.letters = _.uniq(first_letters).sort();
        };
      })(this));
    }

    return Controller;

  })();

  angular.module('app').controller('dictionaryController', ['$scope', '$rootScope', '$location', 'entryService', 'i18nService', Controller]);

}).call(this);
