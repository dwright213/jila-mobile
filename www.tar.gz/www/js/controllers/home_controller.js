(function() {
  var Controller;

  Controller = (function() {
    function Controller($scope, $rootScope, i18nService) {
      var WARNING_KEY, showWarningMessage, warningSeen;
      $rootScope.$emit('navigationConfig', {
        labelForTitle: i18nService.get('homeTitle'),
        backAction: null
      });
      $scope.labelForDictionary = i18nService.get('homeDictionary');
      $scope.labelForCategories = i18nService.get('homeCategories');
      $scope.labelForLearn = i18nService.get('homeLearn');
      $scope.labelForCommon = i18nService.get('homeCommon');
      $scope.labelForWordOfTheDay = i18nService.get('homeWordOfTheDay');
      $scope.labelForAbout = i18nService.get('homeAbout');
      WARNING_KEY = 'warningSeen';
      warningSeen = function() {
        window.localStorage[WARNING_KEY] = true;
      };
      showWarningMessage = function() {
        var warningButton, warningMessage, warningTitle;
        warningTitle = i18nService.get('homeWarningTitle');
        warningButton = i18nService.get('acknowledgeButton');
        warningMessage = i18nService.get('homeWarningMessage');
        if (navigator.notification) {
          return navigator.notification.alert(warningMessage, warningSeen, warningTitle, warningButton);
        } else {
          alert(warningMessage);
          return warningSeen();
        }
      };
      if (!window.localStorage[WARNING_KEY]) {
        showWarningMessage();
      }
    }

    return Controller;

  })();

  angular.module('app').controller('homeController', ['$scope', '$rootScope', 'i18nService', Controller]);

}).call(this);
