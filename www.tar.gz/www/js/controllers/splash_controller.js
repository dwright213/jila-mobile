(function() {
  var Controller;

  Controller = (function() {
    function Controller($scope, $rootScope, $location, $timeout, SPLASH_SCREEN_DELAY, syncService, configurationService, i18nService) {
      var delayFinished, syncFailed, syncFinished, syncRemoteContent, syncSuccess, transitionIfFinished;
      $rootScope.$emit('navigationConfig', {
        navigationAvailable: false,
        searchAvailable: false
      });
      syncFinished = false;
      delayFinished = false;
      $scope.retryAvailable = false;
      $scope.retryButtonMessage = i18nService.get('syncRetryButtonMessage');
      $scope.retrySync = function() {
        return syncRemoteContent();
      };
      transitionIfFinished = function() {
        if (syncFinished && delayFinished) {
          return $location.path('/home');
        }
      };
      syncSuccess = function() {
        syncFinished = true;
        transitionIfFinished();
      };
      syncFailed = function() {
        if (configurationService.initialSyncComplete()) {
          alert(i18nService.get('syncFailureOfflineMessage'));
          syncFinished = true;
          transitionIfFinished();
        } else {
          alert(i18nService.get('syncFailureRetryMessage'));
          $scope.retryAvailable = true;
        }
      };
      syncRemoteContent = function() {
        return syncService.refresh().then(syncSuccess, syncFailed);
      };
      Platform.isReady(function() {
        $timeout(function() {
          delayFinished = true;
          return transitionIfFinished();
        }, SPLASH_SCREEN_DELAY);
        if (window.navigator.onLine) {
          return syncRemoteContent();
        } else {
          return syncFailed();
        }
      });
    }

    return Controller;

  })();

  angular.module('app').controller('splashController', ['$scope', '$rootScope', '$location', '$timeout', 'SPLASH_SCREEN_DELAY', 'syncService', 'configurationService', 'i18nService', Controller]);

}).call(this);
