(function() {
  var Controller;

  Controller = (function() {
    function Controller($scope, $routeParams, $rootScope, $location, $q, $timeout, entryService, i18nService) {
      var addEntries, computeAndRenderBatch;
      $rootScope.$emit('navigationConfig', {
        labelForTitle: $routeParams.letterId,
        backAction: function() {
          $location.path('/dictionary');
        }
      });
      $scope.entries = [];
      addEntries = function(entries) {
        [].push.apply($scope.entries, entries);
        return $timeout(angular.noop, 0);
      };
      computeAndRenderBatch = function(entries) {
        var batch, batchSize, batches, computeAndLetUIRender, computeNextBatch, i, len;
        computeAndLetUIRender = $q.when();
        batchSize = 30;
        batches = _.chunk(entries, batchSize);
        for (i = 0, len = batches.length; i < len; i++) {
          batch = batches[i];
          computeNextBatch = angular.bind(null, addEntries, batch);
          computeAndLetUIRender = computeAndLetUIRender.then(computeNextBatch);
        }
        return computeAndLetUIRender;
      };
      entryService.entries_for_letter($routeParams.letterId).then((function(_this) {
        return function(entries) {
          return _.sortBy(entries, 'entry_word');
        };
      })(this)).then(function(entries) {
        return computeAndRenderBatch(entries);
      });
    }

    return Controller;

  })();

  angular.module('app').controller('letterController', ['$scope', '$routeParams', '$rootScope', '$location', '$q', '$timeout', 'entryService', 'i18nService', Controller]);

}).call(this);
