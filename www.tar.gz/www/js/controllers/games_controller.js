(function() {
  var Controller;

  Controller = (function() {
    function Controller($scope, $rootScope, $location, categoryService, gameService, i18nService) {
      $rootScope.$emit('navigationConfig', {
        labelForTitle: i18nService.get('gamesTitle'),
        backAction: function() {
          $location.path('/home');
        }
      });
      $scope.categories = [];
      categoryService.all().then((function(_this) {
        return function(categories) {
          return $scope.categories = categories;
        };
      })(this));
      $scope.startGamesFor = function(category) {
        return gameService.setupGamesFor(category.id);
      };
    }

    return Controller;

  })();

  angular.module('app').controller('gamesController', ['$scope', '$rootScope', '$location', 'categoryService', 'gameService', 'i18nService', Controller]);

}).call(this);
