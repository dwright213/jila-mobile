(function() {
  var Controller;

  Controller = (function() {
    function Controller($scope, $rootScope, $location, categoryService, i18nService) {
      $rootScope.$emit('navigationConfig', {
        labelForTitle: i18nService.get('categoriesTitle'),
        backAction: function() {
          $location.path('/home');
        }
      });
      $scope.categories = [];
      categoryService.all().then((function(_this) {
        return function(categories) {
          return $scope.categories = categories;
        };
      })(this));
    }

    return Controller;

  })();

  angular.module('app').controller('categoriesController', ['$scope', '$rootScope', '$location', 'categoryService', 'i18nService', Controller]);

}).call(this);
