(function() {
  var Controller;

  Controller = (function() {
    function Controller($scope, $rootScope, $location, entryService, audioService, i18nService) {
      $rootScope.$emit('navigationConfig', {
        labelForTitle: i18nService.get('wordOfTheDayTitle'),
        backAction: function() {
          $location.path('/home');
        }
      });
      $scope.entry = {};
      $scope.listen = function() {
        if ($scope.entry.audio) {
          audioService.play($scope.entry.audio);
        }
      };
      entryService.all().then(function(entries) {
        var index, today;
        today = moment('0', 'hh').unix();
        index = Math.floor(Math.randomWithSeed(today) * entries.length) - 1;
        return $scope.entry = entries[index];
      });
    }

    return Controller;

  })();

  angular.module('app').controller('wordOfTheDayController', ['$scope', '$rootScope', '$location', 'entryService', 'audioService', 'i18nService', Controller]);

}).call(this);
