(function() {
  var Controller;

  Controller = (function() {
    function Controller($scope, $routeParams, categoryService, entryService, $rootScope, $location, $q, $timeout) {
      var addEntries, computeAndRenderBatch;
      $rootScope.$emit('navigationConfig', {
        labelForTitle: '',
        backAction: function() {
          $location.path('/categories');
        }
      });
      $scope.category = {};
      $scope.entries = [];
      addEntries = function(entries) {
        [].push.apply($scope.entries, entries);
        return $timeout(angular.noop, 0);
      };
      computeAndRenderBatch = function(entries) {
        var batch, batchSize, batches, computeAndLetUIRender, computeNextBatch, i, len;
        computeAndLetUIRender = $q.when();
        batchSize = 30;
        batches = _.chunk(entries, batchSize);
        for (i = 0, len = batches.length; i < len; i++) {
          batch = batches[i];
          computeNextBatch = angular.bind(null, addEntries, batch);
          computeAndLetUIRender = computeAndLetUIRender.then(computeNextBatch);
        }
        return computeAndLetUIRender;
      };
      categoryService.get($routeParams.categoryId).then(function(category) {
        $rootScope.$emit('navigationConfig', {
          labelForTitle: category.name
        });
        $scope.category = category;
        return entryService.entries_for(category.id);
      }).then(function(entries) {
        return computeAndRenderBatch(entries);
      }).then(function(_) {
        return console.log('done');
      });
    }

    return Controller;

  })();

  angular.module('app').controller('categoryController', ['$scope', '$routeParams', 'categoryService', 'entryService', '$rootScope', '$location', '$q', '$timeout', Controller]);

}).call(this);
