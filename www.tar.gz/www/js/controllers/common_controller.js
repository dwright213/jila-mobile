(function() {
  var Controller;

  Controller = (function() {
    function Controller($scope, $rootScope, $location, audioService, entryService, i18nService, COMMON_CATEGORY_ID) {
      $rootScope.$emit('navigationConfig', {
        labelForTitle: i18nService.get('commonTitle'),
        backAction: function() {
          $location.path('/home');
        }
      });
      $scope.entries = [];
      $scope.listen = function(entry) {
        if (entry.audio) {
          audioService.play(entry.audio);
        }
      };
      entryService.entries_for(COMMON_CATEGORY_ID).then((function(_this) {
        return function(entries) {
          return $scope.entries = entries;
        };
      })(this));
    }

    return Controller;

  })();

  angular.module('app').controller('commonController', ['$scope', '$rootScope', '$location', 'audioService', 'entryService', 'i18nService', 'COMMON_CATEGORY_ID', Controller]);

}).call(this);
