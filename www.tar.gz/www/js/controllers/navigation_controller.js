(function() {
  var Controller;

  Controller = (function() {
    function Controller($scope, $rootScope, $timeout, $location, entryService, i18nService) {
      var searchAction, searchFor;
      $scope.labelForSearch = i18nService.get('placeholderSearch');
      $scope.backAction = null;
      $scope.searchAvailable = false;
      $scope.searchIsVisible = false;
      $scope.navigationAvailable = false;
      $scope.searchString = '';
      $scope.entries = [];
      $rootScope.$on('$locationChangeStart', function() {
        $scope.searchIsVisible = false;
        $scope.searchAvailable = true;
      });
      $rootScope.$on('navigationConfig', function(e, config) {
        $timeout(function() {
          if (config.labelForTitle !== void 0) {
            $scope.labelForTitle = config.labelForTitle;
          }
          if (config.backAction !== void 0) {
            $scope.backAction = config.backAction;
          }
          if (config.searchAvailable !== void 0) {
            $scope.searchAvailable = config.searchAvailable;
          }
          if (config.navigationAvailable !== void 0) {
            return $scope.navigationAvailable = config.navigationAvailable;
          } else {
            return $scope.navigationAvailable = true;
          }
        });
      });
      document.addEventListener('backbutton', function(e) {
        $scope.$apply(function() {
          $scope.backClicked();
        });
      });
      window.backInProgress = 0;
      $scope.backClicked = (function(_this) {
        return function() {
          $scope.hideSearch();
          if ($scope.backAction) {
            window.backInProgress++;
            $('body').addClass('back');
            $scope.backAction();
          } else {
            if ($location.path() === '/home') {
              navigator.app.exitApp();
            }
          }
        };
      })(this);
      $scope.toggleSearch = (function(_this) {
        return function() {
          return $scope.searchIsVisible = !$scope.searchIsVisible;
        };
      })(this);
      $scope.hideSearch = (function(_this) {
        return function() {
          return $scope.searchIsVisible = false;
        };
      })(this);
      searchAction = null;
      searchFor = (function(_this) {
        return function(query) {
          return entryService.search_for($scope.searchString).then(function(entries) {
            return $scope.entries = entries;
          });
        };
      })(this);
      $scope.searchStringChanged = (function(_this) {
        return function() {
          var searchString;
          if (searchAction) {
            $timeout.cancel(searchAction);
          }
          if ($scope.searchString) {
            searchString = $scope.searchString;
            return searchAction = $timeout(function() {
              return searchFor(searchString);
            }, 300);
          } else {
            return $scope.entries = [];
          }
        };
      })(this);
    }

    return Controller;

  })();

  angular.module('app').controller('navigationController', ['$scope', '$rootScope', '$timeout', '$location', 'entryService', 'i18nService', Controller]);

}).call(this);
