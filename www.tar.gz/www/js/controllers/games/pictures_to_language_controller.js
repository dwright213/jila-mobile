(function() {
  var Controller,
    bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
    extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
    hasProp = {}.hasOwnProperty;

  Controller = (function(superClass) {
    extend(Controller, superClass);

    function Controller($scope, $routeParams, submissionHandler, optionsGenerator, $rootScope, $location, i18nService) {
      this.$scope = $scope;
      this.$routeParams = $routeParams;
      this.submissionHandler = submissionHandler;
      this.optionsGenerator = optionsGenerator;
      this.$rootScope = $rootScope;
      this.$location = $location;
      this.i18nService = i18nService;
      this.answerImage = bind(this.answerImage, this);
      Controller.__super__.constructor.apply(this, arguments);
      this.$scope.labelForInstruction = this.i18nService.get('instructionMatchPicture');
    }

    Controller.prototype.validOptionsFrom = function(allOptions) {
      return this.validOptionsForPictureGameFrom(allOptions);
    };

    Controller.prototype.displayOptions = function(validOptionsFrom) {
      return validOptionsFrom.map(function(o) {
        return {
          label: o.entry_word,
          image: o.images.thumbnail
        };
      });
    };

    Controller.prototype.numOptionsRequired = function() {
      return 4;
    };

    Controller.prototype.answerImage = function() {
      return this.$scope.answer.image;
    };

    return Controller;

  })(BaseGameController);

  angular.module('app').controller('picturesToLanguageController', ['$scope', '$routeParams', 'submissionHandlerService', 'optionsGeneratorService', '$rootScope', '$location', 'i18nService', Controller]);

}).call(this);
