(function() {
  var Controller,
    extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
    hasProp = {}.hasOwnProperty;

  Controller = (function(superClass) {
    extend(Controller, superClass);

    function Controller($scope, $routeParams, audioService, submissionHandler, optionsGenerator, $rootScope, $location, i18nService) {
      this.$scope = $scope;
      this.$routeParams = $routeParams;
      this.audioService = audioService;
      this.submissionHandler = submissionHandler;
      this.optionsGenerator = optionsGenerator;
      this.$rootScope = $rootScope;
      this.$location = $location;
      this.i18nService = i18nService;
      Controller.__super__.constructor.apply(this, arguments);
      this.$scope.labelForInstruction = this.i18nService.get('instructionSelectMatch');
    }

    Controller.prototype.validOptionsFrom = function(allOptions) {
      return this.validOptionsForAudioGameFrom(allOptions);
    };

    Controller.prototype.displayOptions = function(validOptionsFrom) {
      return validOptionsFrom.map(function(o) {
        return {
          label: o.translation,
          audio: o.audio
        };
      });
    };

    return Controller;

  })(BaseGameController);

  angular.module('app').controller('audioToTranslationController', ['$scope', '$routeParams', 'audioService', 'submissionHandlerService', 'optionsGeneratorService', '$rootScope', '$location', 'i18nService', Controller]);

}).call(this);
