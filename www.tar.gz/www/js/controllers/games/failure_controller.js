(function() {
  var Controller;

  Controller = (function() {
    function Controller($scope, $location, $timeout, i18nService) {
      $scope.labelForTitle = i18nService.get('sessionTitleFailure');
      $scope.labelForMessage = i18nService.get('sessionMessageFailure');
      $scope.labelForClose = i18nService.get('acknowledgeButton');
      $scope.close = function() {
        return $location.path('/games');
      };
      $scope.loaded = false;
      $timeout(function() {
        return $scope.loaded = true;
      }, 0);
    }

    return Controller;

  })();

  angular.module('app').controller('failureController', ['$scope', '$location', '$timeout', 'i18nService', Controller]);

}).call(this);
