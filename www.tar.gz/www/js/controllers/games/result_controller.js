(function() {
  var Controller;

  Controller = (function() {
    function Controller($scope, $rootScope, $routeParams, $location, $timeout, i18nService) {
      var gameStatus, i, j, lastLifeLost, livesLost, livesRemaining, ref, ref1, results, results1, roundStatus;
      $rootScope.$emit('navigationConfig', {
        searchAvailable: false,
        navigationAvailable: false
      });
      roundStatus = JSON.parse($location.search()['status']);
      $scope.labelForTitle = roundStatus.resultTitle;
      $scope.labelForMessage = roundStatus.explanation;
      $scope.answerImage = roundStatus.correctImage;
      $scope.labelForClose = i18nService.get('acknowledgeButton');
      gameStatus = roundStatus.gameStatus;
      $scope.success = gameStatus.lastRoundSuccessful;
      livesLost = gameStatus.livesLost ? (function() {
        results = [];
        for (var i = 0, ref = gameStatus.livesLost - 1; 0 <= ref ? i <= ref : i >= ref; 0 <= ref ? i++ : i--){ results.push(i); }
        return results;
      }).apply(this).map(function() {
        return {
          lost: true
        };
      }) : [];
      livesRemaining = gameStatus.livesRemaining ? (function() {
        results1 = [];
        for (var j = 0, ref1 = gameStatus.livesRemaining - 1; 0 <= ref1 ? j <= ref1 : j >= ref1; 0 <= ref1 ? j++ : j--){ results1.push(j); }
        return results1;
      }).apply(this).map(function() {
        return {
          lost: false
        };
      }) : [];
      $scope.lives = livesLost.concat(livesRemaining);
      if (!gameStatus.lastRoundSuccessful) {
        lastLifeLost = _.last(livesLost);
        lastLifeLost.lost = false;
        $timeout(function() {
          return lastLifeLost.lost = true;
        }, 1500);
      }
      $scope.close = function() {
        var nextGame, remainingGames;
        if (gameStatus.gameInProgress) {
          remainingGames = JSON.parse($location.search()['games']);
          if (remainingGames.length > 0) {
            nextGame = remainingGames.pop();
            return $location.path("/games/" + $routeParams.categoryId + "/" + nextGame).search("games=" + (JSON.stringify(remainingGames)));
          } else {
            return $location.path('/games/success').search('');
          }
        } else {
          return $location.path('/games/failure').search('');
        }
      };
      $scope.loaded = false;
      $timeout(function() {
        return $scope.loaded = true;
      }, 500);
    }

    return Controller;

  })();

  angular.module('app').controller('resultController', ['$scope', '$rootScope', '$routeParams', '$location', '$timeout', 'i18nService', Controller]);

}).call(this);
