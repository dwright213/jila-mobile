(function() {
  var BaseGameController,
    bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

  BaseGameController = (function() {
    function BaseGameController() {
      this.answerTextIsAcceptable = bind(this.answerTextIsAcceptable, this);
      this.answerTextIsValid = bind(this.answerTextIsValid, this);
      this.allowsAcceptableAnswer = bind(this.allowsAcceptableAnswer, this);
      this.jumbleAnswer = bind(this.jumbleAnswer, this);
      this.categoryId = bind(this.categoryId, this);
      this.submitDisabled = bind(this.submitDisabled, this);
      this.$rootScope.$emit('navigationConfig', {
        searchAvailable: false,
        labelForTitle: '',
        backAction: (function(_this) {
          return function() {
            var confirmationMessage, exit, goHome;
            goHome = function() {
              _this.$location.path('/games').search('');
            };
            confirmationMessage = _this.i18nService.get('exitGameConfirmation');
            if (navigator.notification) {
              return navigator.notification.confirm(confirmationMessage, function(button) {
                return _this.$rootScope.$apply(function() {
                  if (button === 1) {
                    return goHome();
                  }
                });
              });
            } else {
              exit = confirm(confirmationMessage);
              if (exit) {
                goHome();
              }
            }
          };
        })(this)
      });
      this.$scope.answer = null;
      this.$scope.selectedAnswer = null;
      this.$scope.options = [];
      this.$scope.labelForSubmit = 'Submit';
      this.optionsGenerator.generateOptionsFor(this, this.$routeParams.categoryId).then((function(_this) {
        return function(generatedOptions) {
          _this.$scope.answer = generatedOptions.answer;
          _this.$scope.options = generatedOptions.options;
          if (_this.onOptionsGenerated) {
            return _this.onOptionsGenerated();
          }
        };
      })(this));
      this.$scope.sortableOptions = {
        tolerance: 'pointer',
        axis: 'x',
        placeholder: 'sortable-placeholder',
        forcePlaceholderSize: true
      };
      this.$scope.select = (function(_this) {
        return function(option) {
          return _this.$scope.selectedAnswer = option;
        };
      })(this);
      this.$scope.submitDisabled = this.submitDisabled;
      this.$scope.listen = (function(_this) {
        return function() {
          _this.audioService.play(_this.$scope.answer.audio);
        };
      })(this);
      this.$scope.submit = (function(_this) {
        return function() {
          if (_this.audioService) {
            _this.audioService.stop();
          }
          return _this.submissionHandler.handleSubmissionFor(_this);
        };
      })(this);
    }

    BaseGameController.prototype.submitDisabled = function() {
      return !this.$scope.selectedAnswer;
    };

    BaseGameController.prototype.categoryId = function() {
      return this.$routeParams.categoryId;
    };

    BaseGameController.prototype.validOptionsFrom = function(allOptions) {
      return allOptions;
    };

    BaseGameController.prototype.displayOptions = function(validOptionsFrom) {
      return validOptionsFrom;
    };

    BaseGameController.prototype.validOptionsForAudioGameFrom = function(allOptions) {
      return _.filter(allOptions, function(o) {
        return o.audio !== null;
      });
    };

    BaseGameController.prototype.validOptionsForPictureGameFrom = function(allOptions) {
      return _.filter(allOptions, function(o) {
        return o.images.thumbnail !== null;
      });
    };

    BaseGameController.prototype.jumbleAnswer = function() {
      var baseAnswer, jumbledSegments, numberSegments, segmentSize, splitSegments;
      baseAnswer = this.$scope.answer.label.toLowerCase();
      if (baseAnswer.isPhrase()) {
        splitSegments = baseAnswer.split(' ').map(function(s) {
          return s.onlyAlphanumeric();
        });
      } else {
        baseAnswer = baseAnswer.onlyAlphanumeric();
        numberSegments = baseAnswer.length > 4 ? 3 : 2;
        segmentSize = Math.ceil(baseAnswer.length / numberSegments);
        splitSegments = baseAnswer.splitIntoSegmentsOf(segmentSize);
      }
      jumbledSegments = _.sample(splitSegments, splitSegments.length);
      while (baseAnswer.indexOf(jumbledSegments[0]) === 0) {
        jumbledSegments = _.sample(splitSegments, splitSegments.length);
      }
      this.$scope.jumbledAnswer = jumbledSegments;
    };

    BaseGameController.prototype.numOptionsRequired = function() {
      return 3;
    };

    BaseGameController.prototype.hasValidAnswer = function() {
      return this.$scope.answer === this.$scope.selectedAnswer;
    };

    BaseGameController.prototype.allowsAcceptableAnswer = function() {
      return this.hasAcceptableAnswer;
    };

    BaseGameController.prototype.stringsAreEqual = function(t1, t2) {
      var sanitized_t1, sanitized_t2;
      sanitized_t1 = t1.sanitize();
      sanitized_t2 = t2.sanitize();
      return sanitized_t1 === sanitized_t2;
    };

    BaseGameController.prototype.stringsAreEquivalent = function(t1, t2) {
      var sanitized_t1, sanitized_t2;
      sanitized_t1 = t1.sanitize();
      sanitized_t2 = t2.sanitize();
      return sanitized_t1[0] === sanitized_t2[0] && sanitized_t1.levenshteinDistance(sanitized_t2) < 2;
    };

    BaseGameController.prototype.answerTextIsValid = function() {
      if (this.stringsAreEqual(this.$scope.answer.label, this.$scope.selectedAnswer)) {
        return true;
      }
      return _.any(this.$scope.answer.alternate_answers, (function(_this) {
        return function(alternate) {
          return _this.stringsAreEqual(alternate, _this.$scope.selectedAnswer);
        };
      })(this));
    };

    BaseGameController.prototype.answerTextIsAcceptable = function() {
      if (this.stringsAreEquivalent(this.$scope.answer.label, this.$scope.selectedAnswer)) {
        return true;
      }
      return _.any(this.$scope.answer.alternate_answers, (function(_this) {
        return function(alternate) {
          return _this.stringsAreEquivalent(alternate, _this.$scope.selectedAnswer);
        };
      })(this));
    };

    return BaseGameController;

  })();

  window.BaseGameController = BaseGameController;

}).call(this);
