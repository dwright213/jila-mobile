(function() {
  if (typeof String.prototype.hashCode === 'undefined') {
    String.prototype.hashCode = function() {
      var chr, hash, i, len;
      hash = 0;
      i = void 0;
      chr = void 0;
      len = void 0;
      if (this.length === 0) {
        return hash;
      }
      i = 0;
      len = this.length;
      while (i < len) {
        chr = this.charCodeAt(i);
        hash = ((hash << 5) - hash) + chr;
        hash |= 0;
        i++;
      }
      return hash;
    };
  }

  if (typeof String.prototype.trim === 'undefined') {
    String.prototype.trim = function() {
      return String(this).replace(/^\s+|\s+$/g, '');
    };
  }

  if (typeof String.prototype.isPhrase === 'undefined') {
    String.prototype.isPhrase = function() {
      return this.split(' ').length > 1;
    };
  }

  if (typeof String.prototype.onlyAlphanumeric === 'undefined') {
    String.prototype.onlyAlphanumeric = function() {
      return this.replace(/\W+/g, '');
    };
  }

  if (typeof String.prototype.sanitize === 'undefined') {
    String.prototype.sanitize = function() {
      return this.trim().toLowerCase().replace(/\s+/g, '').onlyAlphanumeric();
    };
  }

  if (typeof String.prototype.splitIntoSegmentsOf === 'undefined') {
    String.prototype.splitIntoSegmentsOf = function(charactersPerSegment) {
      return this.match(RegExp(".{1," + charactersPerSegment + "}", 'g'));
    };
  }

  if (typeof String.prototype.levenshteinDistance === 'undefined') {
    String.prototype.levenshteinDistance = function(toCompare) {
      var i, j, matrix;
      if (this.length === 0) {
        return toCompare.length;
      }
      if (toCompare.length === 0) {
        return this.length;
      }
      matrix = [];
      i = void 0;
      i = 0;
      while (i <= toCompare.length) {
        matrix[i] = [i];
        i++;
      }
      j = void 0;
      j = 0;
      while (j <= this.length) {
        matrix[0][j] = j;
        j++;
      }
      i = 1;
      while (i <= toCompare.length) {
        j = 1;
        while (j <= this.length) {
          if (toCompare.charAt(i - 1) === this.charAt(j - 1)) {
            matrix[i][j] = matrix[i - 1][j - 1];
          } else {
            matrix[i][j] = Math.min(matrix[i - 1][j - 1] + 1, Math.min(matrix[i][j - 1] + 1, matrix[i - 1][j] + 1));
          }
          j++;
        }
        i++;
      }
      return matrix[toCompare.length][this.length];
    };
  }

}).call(this);
(function() {
  if (typeof Math.randomWithSeed === 'undefined') {
    Math.randomWithSeed = function(seed) {
      var x;
      x = Math.sin(seed) * 10000;
      return x - Math.floor(x);
    };
  }

}).call(this);
(function() {
  var BACKEND_URL;

  BACKEND_URL = 'http://admin.danwright.co';

  angular.module('configuration', []).constant('SPLASH_SCREEN_DELAY', 2000).constant('BACKEND_URL', BACKEND_URL).constant('GAMES_PER_ROUND', 20).constant('LIVES_PER_ROUND', 3).constant('COMMON_CATEGORY_ID', 1);

}).call(this);
(function() {
  var Platform;

  window.isWebView = document.URL.indexOf('http://') === -1 ? true : false;

  Platform = (function() {
    function Platform() {
      this.readyFlag = false;
      this.readyCallbacks = [];
      if (window.isWebView) {
        document.addEventListener('deviceready', (function(_this) {
          return function() {
            _this.readyFlag = true;
            _this.readyCallbacks.forEach(function(cb) {
              return cb();
            });
            return _this.readyCallbacks = [];
          };
        })(this));
      } else {
        this.readyFlag = true;
      }
    }

    Platform.prototype.isReady = function(callback) {
      if (this.readyFlag) {
        return callback();
      } else {
        return this.readyCallbacks.push(callback);
      }
    };

    return Platform;

  })();

  window.Platform = new Platform();

}).call(this);
(function() {
  Platform.isReady(function() {
    var trackingID;
    trackingID = '<insert tracking ID here>';
    if (window.isWebView) {
      ga('create', trackingID, {
        'storage': 'none',
        'clientId': device.uuid
      });
      return ga('set', 'checkProtocolTask', null);
    } else {
      return ga('create', trackingID, 'auto');
    }
  });

}).call(this);
(function() {
  var app;

  app = angular.module('app', ['ngRoute', 'ngTouch', 'ngAnimate', 'ngSanitize', 'configuration', 'angulartics', 'angulartics.google.analytics', 'pasvaz.bindonce']);

  app.config([
    '$compileProvider', function($compileProvider) {
      return $compileProvider.imgSrcSanitizationWhitelist(/^\s*(https?|file|blob|cdvfile):|data:image\//);
    }
  ]);

  marked.setOptions({
    breaks: true,
    sanitize: true
  });

}).call(this);
(function() {
  var app;

  app = angular.module('app');

  app.config([
    '$routeProvider', function($routeProvider) {
      $routeProvider.when('/', {
        templateUrl: 'partials/splash.html',
        controller: 'splashController'
      });
      $routeProvider.when('/home', {
        templateUrl: 'partials/home.html',
        controller: 'homeController'
      });
      $routeProvider.when('/dictionary', {
        templateUrl: 'partials/dictionary.html',
        controller: 'dictionaryController'
      });
      $routeProvider.when('/dictionary/:letterId', {
        templateUrl: 'partials/letter.html',
        controller: 'letterController'
      });
      $routeProvider.when('/categories', {
        templateUrl: 'partials/categories.html',
        controller: 'categoriesController'
      });
      $routeProvider.when('/categories/:categoryId', {
        templateUrl: 'partials/category.html',
        controller: 'categoryController'
      });
      $routeProvider.when('/entries/:entryId', {
        templateUrl: 'partials/entry.html',
        controller: 'entryController'
      });
      $routeProvider.when('/common', {
        templateUrl: 'partials/common.html',
        controller: 'commonController'
      });
      $routeProvider.when('/word_of_the_day', {
        templateUrl: 'partials/entry.html',
        controller: 'wordOfTheDayController'
      });
      $routeProvider.when('/about', {
        templateUrl: 'partials/about.html',
        controller: 'aboutController'
      });
      $routeProvider.when('/games', {
        templateUrl: 'partials/games.html',
        controller: 'gamesController'
      });
      $routeProvider.when('/games/:categoryId/1', {
        templateUrl: 'partials/games/audio_to_options.html',
        controller: 'audioToLanguageController'
      });
      $routeProvider.when('/games/:categoryId/2', {
        templateUrl: 'partials/games/audio_to_options.html',
        controller: 'audioToTranslationController'
      });
      $routeProvider.when('/games/:categoryId/3', {
        templateUrl: 'partials/games/picture_to_options.html',
        controller: 'pictureToLanguageController'
      });
      $routeProvider.when('/games/:categoryId/4', {
        templateUrl: 'partials/games/text_to_pictures.html',
        controller: 'picturesToLanguageController'
      });
      $routeProvider.when('/games/:categoryId/5', {
        templateUrl: 'partials/games/audio_to_text.html',
        controller: 'audioToTranslationTextController'
      });
      $routeProvider.when('/games/:categoryId/6', {
        templateUrl: 'partials/games/text_to_options.html',
        controller: 'languageToTranslationController'
      });
      $routeProvider.when('/games/:categoryId/7', {
        templateUrl: 'partials/games/text_to_text.html',
        controller: 'languageToTranslationTextController'
      });
      $routeProvider.when('/games/:categoryId/8', {
        templateUrl: 'partials/games/audio_to_unjumble.html',
        controller: 'audioToUnjumbleController'
      });
      $routeProvider.when('/games/:categoryId/9', {
        templateUrl: 'partials/games/picture_to_unjumble.html',
        controller: 'pictureToUnjumbleController'
      });
      $routeProvider.when('/games/:categoryId/result', {
        templateUrl: 'partials/games/result.html',
        controller: 'resultController'
      });
      $routeProvider.when('/games/success', {
        templateUrl: 'partials/games/success.html',
        controller: 'successController'
      });
      return $routeProvider.when('/games/failure', {
        templateUrl: 'partials/games/failure.html',
        controller: 'failureController'
      });
    }
  ]);

}).call(this);
(function() {
  var BaseGameController,
    bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

  BaseGameController = (function() {
    function BaseGameController() {
      this.answerTextIsAcceptable = bind(this.answerTextIsAcceptable, this);
      this.answerTextIsValid = bind(this.answerTextIsValid, this);
      this.allowsAcceptableAnswer = bind(this.allowsAcceptableAnswer, this);
      this.jumbleAnswer = bind(this.jumbleAnswer, this);
      this.categoryId = bind(this.categoryId, this);
      this.submitDisabled = bind(this.submitDisabled, this);
      this.$rootScope.$emit('navigationConfig', {
        searchAvailable: false,
        labelForTitle: '',
        backAction: (function(_this) {
          return function() {
            var confirmationMessage, exit, goHome;
            goHome = function() {
              _this.$location.path('/games').search('');
            };
            confirmationMessage = _this.i18nService.get('exitGameConfirmation');
            if (navigator.notification) {
              return navigator.notification.confirm(confirmationMessage, function(button) {
                return _this.$rootScope.$apply(function() {
                  if (button === 1) {
                    return goHome();
                  }
                });
              });
            } else {
              exit = confirm(confirmationMessage);
              if (exit) {
                goHome();
              }
            }
          };
        })(this)
      });
      this.$scope.answer = null;
      this.$scope.selectedAnswer = null;
      this.$scope.options = [];
      this.$scope.labelForSubmit = 'Submit';
      this.optionsGenerator.generateOptionsFor(this, this.$routeParams.categoryId).then((function(_this) {
        return function(generatedOptions) {
          _this.$scope.answer = generatedOptions.answer;
          _this.$scope.options = generatedOptions.options;
          if (_this.onOptionsGenerated) {
            return _this.onOptionsGenerated();
          }
        };
      })(this));
      this.$scope.sortableOptions = {
        tolerance: 'pointer',
        axis: 'x',
        placeholder: 'sortable-placeholder',
        forcePlaceholderSize: true
      };
      this.$scope.select = (function(_this) {
        return function(option) {
          return _this.$scope.selectedAnswer = option;
        };
      })(this);
      this.$scope.submitDisabled = this.submitDisabled;
      this.$scope.listen = (function(_this) {
        return function() {
          _this.audioService.play(_this.$scope.answer.audio);
        };
      })(this);
      this.$scope.submit = (function(_this) {
        return function() {
          if (_this.audioService) {
            _this.audioService.stop();
          }
          return _this.submissionHandler.handleSubmissionFor(_this);
        };
      })(this);
    }

    BaseGameController.prototype.submitDisabled = function() {
      return !this.$scope.selectedAnswer;
    };

    BaseGameController.prototype.categoryId = function() {
      return this.$routeParams.categoryId;
    };

    BaseGameController.prototype.validOptionsFrom = function(allOptions) {
      return allOptions;
    };

    BaseGameController.prototype.displayOptions = function(validOptionsFrom) {
      return validOptionsFrom;
    };

    BaseGameController.prototype.validOptionsForAudioGameFrom = function(allOptions) {
      return _.filter(allOptions, function(o) {
        return o.audio !== null;
      });
    };

    BaseGameController.prototype.validOptionsForPictureGameFrom = function(allOptions) {
      return _.filter(allOptions, function(o) {
        return o.images.thumbnail !== null;
      });
    };

    BaseGameController.prototype.jumbleAnswer = function() {
      var baseAnswer, jumbledSegments, numberSegments, segmentSize, splitSegments;
      baseAnswer = this.$scope.answer.label.toLowerCase();
      if (baseAnswer.isPhrase()) {
        splitSegments = baseAnswer.split(' ').map(function(s) {
          return s.onlyAlphanumeric();
        });
      } else {
        baseAnswer = baseAnswer.onlyAlphanumeric();
        numberSegments = baseAnswer.length > 4 ? 3 : 2;
        segmentSize = Math.ceil(baseAnswer.length / numberSegments);
        splitSegments = baseAnswer.splitIntoSegmentsOf(segmentSize);
      }
      jumbledSegments = _.sample(splitSegments, splitSegments.length);
      while (baseAnswer.indexOf(jumbledSegments[0]) === 0) {
        jumbledSegments = _.sample(splitSegments, splitSegments.length);
      }
      this.$scope.jumbledAnswer = jumbledSegments;
    };

    BaseGameController.prototype.numOptionsRequired = function() {
      return 3;
    };

    BaseGameController.prototype.hasValidAnswer = function() {
      return this.$scope.answer === this.$scope.selectedAnswer;
    };

    BaseGameController.prototype.allowsAcceptableAnswer = function() {
      return this.hasAcceptableAnswer;
    };

    BaseGameController.prototype.stringsAreEqual = function(t1, t2) {
      var sanitized_t1, sanitized_t2;
      sanitized_t1 = t1.sanitize();
      sanitized_t2 = t2.sanitize();
      return sanitized_t1 === sanitized_t2;
    };

    BaseGameController.prototype.stringsAreEquivalent = function(t1, t2) {
      var sanitized_t1, sanitized_t2;
      sanitized_t1 = t1.sanitize();
      sanitized_t2 = t2.sanitize();
      return sanitized_t1[0] === sanitized_t2[0] && sanitized_t1.levenshteinDistance(sanitized_t2) < 2;
    };

    BaseGameController.prototype.answerTextIsValid = function() {
      if (this.stringsAreEqual(this.$scope.answer.label, this.$scope.selectedAnswer)) {
        return true;
      }
      return _.any(this.$scope.answer.alternate_answers, (function(_this) {
        return function(alternate) {
          return _this.stringsAreEqual(alternate, _this.$scope.selectedAnswer);
        };
      })(this));
    };

    BaseGameController.prototype.answerTextIsAcceptable = function() {
      if (this.stringsAreEquivalent(this.$scope.answer.label, this.$scope.selectedAnswer)) {
        return true;
      }
      return _.any(this.$scope.answer.alternate_answers, (function(_this) {
        return function(alternate) {
          return _this.stringsAreEquivalent(alternate, _this.$scope.selectedAnswer);
        };
      })(this));
    };

    return BaseGameController;

  })();

  window.BaseGameController = BaseGameController;

}).call(this);
(function() {
  var Controller;

  Controller = (function() {
    function Controller($scope, $rootScope, $location, imageCreditService, i18nService) {
      $rootScope.$emit('navigationConfig', {
        labelForTitle: i18nService.get('aboutTitle'),
        backAction: function() {
          $location.path('/home');
        }
      });
      $scope.historyTab = {
        label: i18nService.get('aboutHistoryTab')
      };
      $scope.resourcesTab = {
        label: i18nService.get('aboutResourcesTab')
      };
      $scope.locationTab = {
        label: i18nService.get('aboutLocationTab')
      };
      $scope.partnersTab = {
        label: i18nService.get('aboutPartnersTab')
      };
      $scope.creditsTab = {
        label: i18nService.get('aboutCreditsTab')
      };
      $scope.tabs = [$scope.historyTab, $scope.resourcesTab, $scope.locationTab, $scope.partnersTab, $scope.creditsTab];
      $scope.imageCredits = [];
      imageCreditService.all().then(function(credits) {
        return $scope.imageCredits = credits;
      });
      $scope.openLink = function(link) {
        return window.open(link, '_system');
      };
      $scope.indexChanged = function(index) {
        return $scope.selectedTab = $scope.tabs[index];
      };
      $scope.selectContent = function(index) {
        $scope.indexChanged(index);
        $scope.content.slickGoTo(index);
      };
      $scope.selectedTab = $scope.historyTab;
    }

    return Controller;

  })();

  angular.module('app').controller('aboutController', ['$scope', '$rootScope', '$location', 'imageCreditService', 'i18nService', Controller]);

}).call(this);
(function() {
  var Controller;

  Controller = (function() {
    function Controller($scope, $rootScope, $location, categoryService, i18nService) {
      $rootScope.$emit('navigationConfig', {
        labelForTitle: i18nService.get('categoriesTitle'),
        backAction: function() {
          $location.path('/home');
        }
      });
      $scope.categories = [];
      categoryService.all().then((function(_this) {
        return function(categories) {
          return $scope.categories = categories;
        };
      })(this));
    }

    return Controller;

  })();

  angular.module('app').controller('categoriesController', ['$scope', '$rootScope', '$location', 'categoryService', 'i18nService', Controller]);

}).call(this);
(function() {
  var Controller;

  Controller = (function() {
    function Controller($scope, $routeParams, categoryService, entryService, $rootScope, $location, $q, $timeout) {
      var addEntries, computeAndRenderBatch;
      $rootScope.$emit('navigationConfig', {
        labelForTitle: '',
        backAction: function() {
          $location.path('/categories');
        }
      });
      $scope.category = {};
      $scope.entries = [];
      addEntries = function(entries) {
        [].push.apply($scope.entries, entries);
        return $timeout(angular.noop, 0);
      };
      computeAndRenderBatch = function(entries) {
        var batch, batchSize, batches, computeAndLetUIRender, computeNextBatch, i, len;
        computeAndLetUIRender = $q.when();
        batchSize = 30;
        batches = _.chunk(entries, batchSize);
        for (i = 0, len = batches.length; i < len; i++) {
          batch = batches[i];
          computeNextBatch = angular.bind(null, addEntries, batch);
          computeAndLetUIRender = computeAndLetUIRender.then(computeNextBatch);
        }
        return computeAndLetUIRender;
      };
      categoryService.get($routeParams.categoryId).then(function(category) {
        $rootScope.$emit('navigationConfig', {
          labelForTitle: category.name
        });
        $scope.category = category;
        return entryService.entries_for(category.id);
      }).then(function(entries) {
        return computeAndRenderBatch(entries);
      }).then(function(_) {
        return console.log('done');
      });
    }

    return Controller;

  })();

  angular.module('app').controller('categoryController', ['$scope', '$routeParams', 'categoryService', 'entryService', '$rootScope', '$location', '$q', '$timeout', Controller]);

}).call(this);
(function() {
  var Controller;

  Controller = (function() {
    function Controller($scope, $rootScope, $location, audioService, entryService, i18nService, COMMON_CATEGORY_ID) {
      $rootScope.$emit('navigationConfig', {
        labelForTitle: i18nService.get('commonTitle'),
        backAction: function() {
          $location.path('/home');
        }
      });
      $scope.entries = [];
      $scope.listen = function(entry) {
        if (entry.audio) {
          audioService.play(entry.audio);
        }
      };
      entryService.entries_for(COMMON_CATEGORY_ID).then((function(_this) {
        return function(entries) {
          return $scope.entries = entries;
        };
      })(this));
    }

    return Controller;

  })();

  angular.module('app').controller('commonController', ['$scope', '$rootScope', '$location', 'audioService', 'entryService', 'i18nService', 'COMMON_CATEGORY_ID', Controller]);

}).call(this);
(function() {
  var Controller;

  Controller = (function() {
    function Controller($scope, $rootScope, $location, entryService, i18nService) {
      $rootScope.$emit('navigationConfig', {
        labelForTitle: i18nService.get('dictionaryTitle'),
        backAction: function() {
          return $location.path('/home');
        }
      });
      entryService.all().then((function(_this) {
        return function(entries) {
          var first_letters;
          first_letters = _.map(entries, function(entry) {
            return entry.entry_word[0].toUpperCase();
          });
          return $scope.letters = _.uniq(first_letters).sort();
        };
      })(this));
    }

    return Controller;

  })();

  angular.module('app').controller('dictionaryController', ['$scope', '$rootScope', '$location', 'entryService', 'i18nService', Controller]);

}).call(this);
(function() {
  var Controller;

  Controller = (function() {
    function Controller($scope, $routeParams, entryService, audioService, $rootScope) {
      $rootScope.$emit('navigationConfig', {
        labelForTitle: "",
        backAction: function() {
          window.history.back();
        }
      });
      $scope.entry = {};
      entryService.get($routeParams.entryId).then((function(_this) {
        return function(entry) {
          $scope.entry = entry;
          $scope.formattedDescription = marked(entry.description);
          return $rootScope.$emit('navigationConfig', {
            labelForTitle: entry.entry_word
          });
        };
      })(this));
      $scope.listen = (function(_this) {
        return function() {
          if ($scope.entry) {
            audioService.play($scope.entry.audio);
          }
        };
      })(this);
    }

    return Controller;

  })();

  angular.module('app').controller('entryController', ['$scope', '$routeParams', 'entryService', 'audioService', '$rootScope', Controller]);

}).call(this);
(function() {
  var Controller,
    extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
    hasProp = {}.hasOwnProperty;

  Controller = (function(superClass) {
    extend(Controller, superClass);

    function Controller($scope, $routeParams, audioService, submissionHandler, optionsGenerator, $rootScope, $location, i18nService) {
      this.$scope = $scope;
      this.$routeParams = $routeParams;
      this.audioService = audioService;
      this.submissionHandler = submissionHandler;
      this.optionsGenerator = optionsGenerator;
      this.$rootScope = $rootScope;
      this.$location = $location;
      this.i18nService = i18nService;
      Controller.__super__.constructor.apply(this, arguments);
      this.$scope.labelForInstruction = this.i18nService.get('instructionSelectMatch');
    }

    Controller.prototype.validOptionsFrom = function(allOptions) {
      return this.validOptionsForAudioGameFrom(allOptions);
    };

    Controller.prototype.displayOptions = function(validOptionsFrom) {
      return validOptionsFrom.map(function(o) {
        return {
          label: o.entry_word,
          audio: o.audio
        };
      });
    };

    return Controller;

  })(BaseGameController);

  angular.module('app').controller('audioToLanguageController', ['$scope', '$routeParams', 'audioService', 'submissionHandlerService', 'optionsGeneratorService', '$rootScope', '$location', 'i18nService', Controller]);

}).call(this);
(function() {
  var Controller,
    extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
    hasProp = {}.hasOwnProperty;

  Controller = (function(superClass) {
    extend(Controller, superClass);

    function Controller($scope, $routeParams, audioService, submissionHandler, optionsGenerator, $rootScope, $location, i18nService) {
      this.$scope = $scope;
      this.$routeParams = $routeParams;
      this.audioService = audioService;
      this.submissionHandler = submissionHandler;
      this.optionsGenerator = optionsGenerator;
      this.$rootScope = $rootScope;
      this.$location = $location;
      this.i18nService = i18nService;
      Controller.__super__.constructor.apply(this, arguments);
      this.$scope.labelForInstruction = this.i18nService.get('instructionSelectMatch');
    }

    Controller.prototype.validOptionsFrom = function(allOptions) {
      return this.validOptionsForAudioGameFrom(allOptions);
    };

    Controller.prototype.displayOptions = function(validOptionsFrom) {
      return validOptionsFrom.map(function(o) {
        return {
          label: o.translation,
          audio: o.audio
        };
      });
    };

    return Controller;

  })(BaseGameController);

  angular.module('app').controller('audioToTranslationController', ['$scope', '$routeParams', 'audioService', 'submissionHandlerService', 'optionsGeneratorService', '$rootScope', '$location', 'i18nService', Controller]);

}).call(this);
(function() {
  var Controller,
    bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
    extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
    hasProp = {}.hasOwnProperty;

  Controller = (function(superClass) {
    extend(Controller, superClass);

    function Controller($scope, $routeParams, audioService, submissionHandler, optionsGenerator, $rootScope, $location, i18nService) {
      this.$scope = $scope;
      this.$routeParams = $routeParams;
      this.audioService = audioService;
      this.submissionHandler = submissionHandler;
      this.optionsGenerator = optionsGenerator;
      this.$rootScope = $rootScope;
      this.$location = $location;
      this.i18nService = i18nService;
      this.hasAcceptableAnswer = bind(this.hasAcceptableAnswer, this);
      this.hasValidAnswer = bind(this.hasValidAnswer, this);
      Controller.__super__.constructor.apply(this, arguments);
      this.$scope.labelForInstruction = this.i18nService.get('instructionTranslateAudio');
      this.$scope.labelForPlaceholder = this.i18nService.get('placeholderAnswer');
    }

    Controller.prototype.validOptionsFrom = function(allOptions) {
      return this.validOptionsForAudioGameFrom(allOptions);
    };

    Controller.prototype.displayOptions = function(validOptionsFrom) {
      return validOptionsFrom.map(function(o) {
        return {
          label: o.translation,
          alternate_answers: o.alternate_translations,
          audio: o.audio
        };
      });
    };

    Controller.prototype.hasValidAnswer = function() {
      return this.answerTextIsValid();
    };

    Controller.prototype.hasAcceptableAnswer = function() {
      return this.answerTextIsAcceptable();
    };

    Controller.prototype.numOptionsRequired = function() {
      return 1;
    };

    return Controller;

  })(BaseGameController);

  angular.module('app').controller('audioToTranslationTextController', ['$scope', '$routeParams', 'audioService', 'submissionHandlerService', 'optionsGeneratorService', '$rootScope', '$location', 'i18nService', Controller]);

}).call(this);
(function() {
  var Controller,
    bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
    extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
    hasProp = {}.hasOwnProperty;

  Controller = (function(superClass) {
    extend(Controller, superClass);

    function Controller($scope, $routeParams, submissionHandler, optionsGenerator, audioService, $rootScope, $location, i18nService) {
      this.$scope = $scope;
      this.$routeParams = $routeParams;
      this.submissionHandler = submissionHandler;
      this.optionsGenerator = optionsGenerator;
      this.audioService = audioService;
      this.$rootScope = $rootScope;
      this.$location = $location;
      this.i18nService = i18nService;
      this.onOptionsGenerated = bind(this.onOptionsGenerated, this);
      this.submitDisabled = bind(this.submitDisabled, this);
      this.hasValidAnswer = bind(this.hasValidAnswer, this);
      Controller.__super__.constructor.apply(this, arguments);
      this.$scope.labelForInstruction = this.i18nService.get('instructionRearrange');
    }

    Controller.prototype.validOptionsFrom = function(allOptions) {
      return this.validOptionsForAudioGameFrom(allOptions);
    };

    Controller.prototype.displayOptions = function(validOptionsFrom) {
      return validOptionsFrom.map(function(o) {
        return {
          label: o.entry_word,
          audio: o.audio
        };
      });
    };

    Controller.prototype.hasValidAnswer = function() {
      this.$scope.selectedAnswer = this.$scope.jumbledAnswer.join('');
      return this.answerTextIsValid();
    };

    Controller.prototype.numOptionsRequired = function() {
      return 1;
    };

    Controller.prototype.submitDisabled = function() {
      return false;
    };

    Controller.prototype.onOptionsGenerated = function() {
      return this.jumbleAnswer();
    };

    return Controller;

  })(BaseGameController);

  angular.module('app').controller('audioToUnjumbleController', ['$scope', '$routeParams', 'submissionHandlerService', 'optionsGeneratorService', 'audioService', '$rootScope', '$location', 'i18nService', Controller]);

}).call(this);
(function() {
  var Controller;

  Controller = (function() {
    function Controller($scope, $location, $timeout, i18nService) {
      $scope.labelForTitle = i18nService.get('sessionTitleFailure');
      $scope.labelForMessage = i18nService.get('sessionMessageFailure');
      $scope.labelForClose = i18nService.get('acknowledgeButton');
      $scope.close = function() {
        return $location.path('/games');
      };
      $scope.loaded = false;
      $timeout(function() {
        return $scope.loaded = true;
      }, 0);
    }

    return Controller;

  })();

  angular.module('app').controller('failureController', ['$scope', '$location', '$timeout', 'i18nService', Controller]);

}).call(this);
(function() {
  var Controller,
    extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
    hasProp = {}.hasOwnProperty;

  Controller = (function(superClass) {
    extend(Controller, superClass);

    function Controller($scope, $routeParams, submissionHandler, optionsGenerator, $rootScope, $location, i18nService) {
      this.$scope = $scope;
      this.$routeParams = $routeParams;
      this.submissionHandler = submissionHandler;
      this.optionsGenerator = optionsGenerator;
      this.$rootScope = $rootScope;
      this.$location = $location;
      this.i18nService = i18nService;
      Controller.__super__.constructor.apply(this, arguments);
      this.$scope.labelForInstruction = this.i18nService.get('instructionSelectMatch');
    }

    Controller.prototype.displayOptions = function(validOptionsFrom) {
      return validOptionsFrom.map(function(o) {
        return {
          label: o.translation,
          answer_label: o.entry_word
        };
      });
    };

    return Controller;

  })(BaseGameController);

  angular.module('app').controller('languageToTranslationController', ['$scope', '$routeParams', 'submissionHandlerService', 'optionsGeneratorService', '$rootScope', '$location', 'i18nService', Controller]);

}).call(this);
(function() {
  var Controller,
    bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
    extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
    hasProp = {}.hasOwnProperty;

  Controller = (function(superClass) {
    extend(Controller, superClass);

    function Controller($scope, $routeParams, submissionHandler, optionsGenerator, $rootScope, $location, i18nService) {
      this.$scope = $scope;
      this.$routeParams = $routeParams;
      this.submissionHandler = submissionHandler;
      this.optionsGenerator = optionsGenerator;
      this.$rootScope = $rootScope;
      this.$location = $location;
      this.i18nService = i18nService;
      this.hasAcceptableAnswer = bind(this.hasAcceptableAnswer, this);
      this.hasValidAnswer = bind(this.hasValidAnswer, this);
      Controller.__super__.constructor.apply(this, arguments);
      this.$scope.labelForInstruction = this.i18nService.get('instructionTranslateWord');
      this.$scope.labelForPlaceholder = this.i18nService.get('placeholderAnswer');
    }

    Controller.prototype.displayOptions = function(validOptionsFrom) {
      return validOptionsFrom.map(function(o) {
        return {
          label: o.translation,
          alternate_answers: o.alternate_translations,
          answer_label: o.entry_word
        };
      });
    };

    Controller.prototype.hasValidAnswer = function() {
      return this.answerTextIsValid();
    };

    Controller.prototype.hasAcceptableAnswer = function() {
      return this.answerTextIsAcceptable();
    };

    Controller.prototype.numOptionsRequired = function() {
      return 1;
    };

    return Controller;

  })(BaseGameController);

  angular.module('app').controller('languageToTranslationTextController', ['$scope', '$routeParams', 'submissionHandlerService', 'optionsGeneratorService', '$rootScope', '$location', 'i18nService', Controller]);

}).call(this);
(function() {
  var Controller,
    extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
    hasProp = {}.hasOwnProperty;

  Controller = (function(superClass) {
    extend(Controller, superClass);

    function Controller($scope, $routeParams, submissionHandler, optionsGenerator, $rootScope, $location, i18nService) {
      this.$scope = $scope;
      this.$routeParams = $routeParams;
      this.submissionHandler = submissionHandler;
      this.optionsGenerator = optionsGenerator;
      this.$rootScope = $rootScope;
      this.$location = $location;
      this.i18nService = i18nService;
      Controller.__super__.constructor.apply(this, arguments);
      this.$scope.labelForInstruction = this.i18nService.get('instructionSelectMatch');
    }

    Controller.prototype.validOptionsFrom = function(allOptions) {
      return this.validOptionsForPictureGameFrom(allOptions);
    };

    Controller.prototype.displayOptions = function(validOptionsFrom) {
      return validOptionsFrom.map(function(o) {
        return {
          label: o.entry_word,
          image: o.images.thumbnail
        };
      });
    };

    return Controller;

  })(BaseGameController);

  angular.module('app').controller('pictureToLanguageController', ['$scope', '$routeParams', 'submissionHandlerService', 'optionsGeneratorService', '$rootScope', '$location', 'i18nService', Controller]);

}).call(this);
(function() {
  var Controller,
    bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
    extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
    hasProp = {}.hasOwnProperty;

  Controller = (function(superClass) {
    extend(Controller, superClass);

    function Controller($scope, $routeParams, submissionHandler, optionsGenerator, $rootScope, $location, i18nService) {
      this.$scope = $scope;
      this.$routeParams = $routeParams;
      this.submissionHandler = submissionHandler;
      this.optionsGenerator = optionsGenerator;
      this.$rootScope = $rootScope;
      this.$location = $location;
      this.i18nService = i18nService;
      this.onOptionsGenerated = bind(this.onOptionsGenerated, this);
      this.submitDisabled = bind(this.submitDisabled, this);
      this.hasValidAnswer = bind(this.hasValidAnswer, this);
      Controller.__super__.constructor.apply(this, arguments);
      this.$scope.labelForInstruction = this.i18nService.get('instructionRearrange');
    }

    Controller.prototype.validOptionsFrom = function(allOptions) {
      return this.validOptionsForPictureGameFrom(allOptions);
    };

    Controller.prototype.displayOptions = function(validOptionsFrom) {
      return validOptionsFrom.map(function(o) {
        return {
          label: o.entry_word,
          image: o.images.thumbnail
        };
      });
    };

    Controller.prototype.hasValidAnswer = function() {
      this.$scope.selectedAnswer = this.$scope.jumbledAnswer.join('');
      return this.answerTextIsValid();
    };

    Controller.prototype.numOptionsRequired = function() {
      return 1;
    };

    Controller.prototype.submitDisabled = function() {
      return false;
    };

    Controller.prototype.onOptionsGenerated = function() {
      return this.jumbleAnswer();
    };

    return Controller;

  })(BaseGameController);

  angular.module('app').controller('pictureToUnjumbleController', ['$scope', '$routeParams', 'submissionHandlerService', 'optionsGeneratorService', '$rootScope', '$location', 'i18nService', Controller]);

}).call(this);
(function() {
  var Controller,
    bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
    extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
    hasProp = {}.hasOwnProperty;

  Controller = (function(superClass) {
    extend(Controller, superClass);

    function Controller($scope, $routeParams, submissionHandler, optionsGenerator, $rootScope, $location, i18nService) {
      this.$scope = $scope;
      this.$routeParams = $routeParams;
      this.submissionHandler = submissionHandler;
      this.optionsGenerator = optionsGenerator;
      this.$rootScope = $rootScope;
      this.$location = $location;
      this.i18nService = i18nService;
      this.answerImage = bind(this.answerImage, this);
      Controller.__super__.constructor.apply(this, arguments);
      this.$scope.labelForInstruction = this.i18nService.get('instructionMatchPicture');
    }

    Controller.prototype.validOptionsFrom = function(allOptions) {
      return this.validOptionsForPictureGameFrom(allOptions);
    };

    Controller.prototype.displayOptions = function(validOptionsFrom) {
      return validOptionsFrom.map(function(o) {
        return {
          label: o.entry_word,
          image: o.images.thumbnail
        };
      });
    };

    Controller.prototype.numOptionsRequired = function() {
      return 4;
    };

    Controller.prototype.answerImage = function() {
      return this.$scope.answer.image;
    };

    return Controller;

  })(BaseGameController);

  angular.module('app').controller('picturesToLanguageController', ['$scope', '$routeParams', 'submissionHandlerService', 'optionsGeneratorService', '$rootScope', '$location', 'i18nService', Controller]);

}).call(this);
(function() {
  var Controller;

  Controller = (function() {
    function Controller($scope, $rootScope, $routeParams, $location, $timeout, i18nService) {
      var gameStatus, i, j, lastLifeLost, livesLost, livesRemaining, ref, ref1, results, results1, roundStatus;
      $rootScope.$emit('navigationConfig', {
        searchAvailable: false,
        navigationAvailable: false
      });
      roundStatus = JSON.parse($location.search()['status']);
      $scope.labelForTitle = roundStatus.resultTitle;
      $scope.labelForMessage = roundStatus.explanation;
      $scope.answerImage = roundStatus.correctImage;
      $scope.labelForClose = i18nService.get('acknowledgeButton');
      gameStatus = roundStatus.gameStatus;
      $scope.success = gameStatus.lastRoundSuccessful;
      livesLost = gameStatus.livesLost ? (function() {
        results = [];
        for (var i = 0, ref = gameStatus.livesLost - 1; 0 <= ref ? i <= ref : i >= ref; 0 <= ref ? i++ : i--){ results.push(i); }
        return results;
      }).apply(this).map(function() {
        return {
          lost: true
        };
      }) : [];
      livesRemaining = gameStatus.livesRemaining ? (function() {
        results1 = [];
        for (var j = 0, ref1 = gameStatus.livesRemaining - 1; 0 <= ref1 ? j <= ref1 : j >= ref1; 0 <= ref1 ? j++ : j--){ results1.push(j); }
        return results1;
      }).apply(this).map(function() {
        return {
          lost: false
        };
      }) : [];
      $scope.lives = livesLost.concat(livesRemaining);
      if (!gameStatus.lastRoundSuccessful) {
        lastLifeLost = _.last(livesLost);
        lastLifeLost.lost = false;
        $timeout(function() {
          return lastLifeLost.lost = true;
        }, 1500);
      }
      $scope.close = function() {
        var nextGame, remainingGames;
        if (gameStatus.gameInProgress) {
          remainingGames = JSON.parse($location.search()['games']);
          if (remainingGames.length > 0) {
            nextGame = remainingGames.pop();
            return $location.path("/games/" + $routeParams.categoryId + "/" + nextGame).search("games=" + (JSON.stringify(remainingGames)));
          } else {
            return $location.path('/games/success').search('');
          }
        } else {
          return $location.path('/games/failure').search('');
        }
      };
      $scope.loaded = false;
      $timeout(function() {
        return $scope.loaded = true;
      }, 500);
    }

    return Controller;

  })();

  angular.module('app').controller('resultController', ['$scope', '$rootScope', '$routeParams', '$location', '$timeout', 'i18nService', Controller]);

}).call(this);
(function() {
  var Controller;

  Controller = (function() {
    function Controller($scope, $location, $timeout, i18nService) {
      $scope.labelForTitle = i18nService.get('sessionTitleSuccess');
      $scope.labelForMessage = i18nService.get('sessionMessageSuccess');
      $scope.labelForClose = i18nService.get('acknowledgeButton');
      $scope.close = function() {
        return $location.path('/games');
      };
      $scope.loaded = false;
      $timeout(function() {
        return $scope.loaded = true;
      }, 0);
    }

    return Controller;

  })();

  angular.module('app').controller('successController', ['$scope', '$location', '$timeout', 'i18nService', Controller]);

}).call(this);
(function() {
  var Controller;

  Controller = (function() {
    function Controller($scope, $rootScope, $location, categoryService, gameService, i18nService) {
      $rootScope.$emit('navigationConfig', {
        labelForTitle: i18nService.get('gamesTitle'),
        backAction: function() {
          $location.path('/home');
        }
      });
      $scope.categories = [];
      categoryService.all().then((function(_this) {
        return function(categories) {
          return $scope.categories = categories;
        };
      })(this));
      $scope.startGamesFor = function(category) {
        return gameService.setupGamesFor(category.id);
      };
    }

    return Controller;

  })();

  angular.module('app').controller('gamesController', ['$scope', '$rootScope', '$location', 'categoryService', 'gameService', 'i18nService', Controller]);

}).call(this);
(function() {
  var Controller;

  Controller = (function() {
    function Controller($scope, $rootScope, i18nService) {
      var WARNING_KEY, showWarningMessage, warningSeen;
      $rootScope.$emit('navigationConfig', {
        labelForTitle: i18nService.get('homeTitle'),
        backAction: null
      });
      $scope.labelForDictionary = i18nService.get('homeDictionary');
      $scope.labelForCategories = i18nService.get('homeCategories');
      $scope.labelForLearn = i18nService.get('homeLearn');
      $scope.labelForCommon = i18nService.get('homeCommon');
      $scope.labelForWordOfTheDay = i18nService.get('homeWordOfTheDay');
      $scope.labelForAbout = i18nService.get('homeAbout');
      WARNING_KEY = 'warningSeen';
      warningSeen = function() {
        window.localStorage[WARNING_KEY] = true;
      };
      showWarningMessage = function() {
        var warningButton, warningMessage, warningTitle;
        warningTitle = i18nService.get('homeWarningTitle');
        warningButton = i18nService.get('acknowledgeButton');
        warningMessage = i18nService.get('homeWarningMessage');
        if (navigator.notification) {
          return navigator.notification.alert(warningMessage, warningSeen, warningTitle, warningButton);
        } else {
          alert(warningMessage);
          return warningSeen();
        }
      };
      if (!window.localStorage[WARNING_KEY]) {
        showWarningMessage();
      }
    }

    return Controller;

  })();

  angular.module('app').controller('homeController', ['$scope', '$rootScope', 'i18nService', Controller]);

}).call(this);
(function() {
  var Controller;

  Controller = (function() {
    function Controller($scope, $routeParams, $rootScope, $location, $q, $timeout, entryService, i18nService) {
      var addEntries, computeAndRenderBatch;
      $rootScope.$emit('navigationConfig', {
        labelForTitle: $routeParams.letterId,
        backAction: function() {
          $location.path('/dictionary');
        }
      });
      $scope.entries = [];
      addEntries = function(entries) {
        [].push.apply($scope.entries, entries);
        return $timeout(angular.noop, 0);
      };
      computeAndRenderBatch = function(entries) {
        var batch, batchSize, batches, computeAndLetUIRender, computeNextBatch, i, len;
        computeAndLetUIRender = $q.when();
        batchSize = 30;
        batches = _.chunk(entries, batchSize);
        for (i = 0, len = batches.length; i < len; i++) {
          batch = batches[i];
          computeNextBatch = angular.bind(null, addEntries, batch);
          computeAndLetUIRender = computeAndLetUIRender.then(computeNextBatch);
        }
        return computeAndLetUIRender;
      };
      entryService.entries_for_letter($routeParams.letterId).then((function(_this) {
        return function(entries) {
          return _.sortBy(entries, 'entry_word');
        };
      })(this)).then(function(entries) {
        return computeAndRenderBatch(entries);
      });
    }

    return Controller;

  })();

  angular.module('app').controller('letterController', ['$scope', '$routeParams', '$rootScope', '$location', '$q', '$timeout', 'entryService', 'i18nService', Controller]);

}).call(this);
(function() {
  var Controller;

  Controller = (function() {
    function Controller($scope, $rootScope, $timeout, $location, entryService, i18nService) {
      var searchAction, searchFor;
      $scope.labelForSearch = i18nService.get('placeholderSearch');
      $scope.backAction = null;
      $scope.searchAvailable = false;
      $scope.searchIsVisible = false;
      $scope.navigationAvailable = false;
      $scope.searchString = '';
      $scope.entries = [];
      $rootScope.$on('$locationChangeStart', function() {
        $scope.searchIsVisible = false;
        $scope.searchAvailable = true;
      });
      $rootScope.$on('navigationConfig', function(e, config) {
        $timeout(function() {
          if (config.labelForTitle !== void 0) {
            $scope.labelForTitle = config.labelForTitle;
          }
          if (config.backAction !== void 0) {
            $scope.backAction = config.backAction;
          }
          if (config.searchAvailable !== void 0) {
            $scope.searchAvailable = config.searchAvailable;
          }
          if (config.navigationAvailable !== void 0) {
            return $scope.navigationAvailable = config.navigationAvailable;
          } else {
            return $scope.navigationAvailable = true;
          }
        });
      });
      document.addEventListener('backbutton', function(e) {
        $scope.$apply(function() {
          $scope.backClicked();
        });
      });
      window.backInProgress = 0;
      $scope.backClicked = (function(_this) {
        return function() {
          $scope.hideSearch();
          if ($scope.backAction) {
            window.backInProgress++;
            $('body').addClass('back');
            $scope.backAction();
          } else {
            if ($location.path() === '/home') {
              navigator.app.exitApp();
            }
          }
        };
      })(this);
      $scope.toggleSearch = (function(_this) {
        return function() {
          return $scope.searchIsVisible = !$scope.searchIsVisible;
        };
      })(this);
      $scope.hideSearch = (function(_this) {
        return function() {
          return $scope.searchIsVisible = false;
        };
      })(this);
      searchAction = null;
      searchFor = (function(_this) {
        return function(query) {
          return entryService.search_for($scope.searchString).then(function(entries) {
            return $scope.entries = entries;
          });
        };
      })(this);
      $scope.searchStringChanged = (function(_this) {
        return function() {
          var searchString;
          if (searchAction) {
            $timeout.cancel(searchAction);
          }
          if ($scope.searchString) {
            searchString = $scope.searchString;
            return searchAction = $timeout(function() {
              return searchFor(searchString);
            }, 300);
          } else {
            return $scope.entries = [];
          }
        };
      })(this);
    }

    return Controller;

  })();

  angular.module('app').controller('navigationController', ['$scope', '$rootScope', '$timeout', '$location', 'entryService', 'i18nService', Controller]);

}).call(this);
(function() {
  var Controller;

  Controller = (function() {
    function Controller($scope, $rootScope, $location, $timeout, SPLASH_SCREEN_DELAY, syncService, configurationService, i18nService) {
      var delayFinished, syncFailed, syncFinished, syncRemoteContent, syncSuccess, transitionIfFinished;
      $rootScope.$emit('navigationConfig', {
        navigationAvailable: false,
        searchAvailable: false
      });
      syncFinished = false;
      delayFinished = false;
      $scope.retryAvailable = false;
      $scope.retryButtonMessage = i18nService.get('syncRetryButtonMessage');
      $scope.retrySync = function() {
        return syncRemoteContent();
      };
      transitionIfFinished = function() {
        if (syncFinished && delayFinished) {
          return $location.path('/home');
        }
      };
      syncSuccess = function() {
        syncFinished = true;
        transitionIfFinished();
      };
      syncFailed = function() {
        if (configurationService.initialSyncComplete()) {
          alert(i18nService.get('syncFailureOfflineMessage'));
          syncFinished = true;
          transitionIfFinished();
        } else {
          alert(i18nService.get('syncFailureRetryMessage'));
          $scope.retryAvailable = true;
        }
      };
      syncRemoteContent = function() {
        return syncService.refresh().then(syncSuccess, syncFailed);
      };
      Platform.isReady(function() {
        $timeout(function() {
          delayFinished = true;
          return transitionIfFinished();
        }, SPLASH_SCREEN_DELAY);
        if (window.navigator.onLine) {
          return syncRemoteContent();
        } else {
          return syncFailed();
        }
      });
    }

    return Controller;

  })();

  angular.module('app').controller('splashController', ['$scope', '$rootScope', '$location', '$timeout', 'SPLASH_SCREEN_DELAY', 'syncService', 'configurationService', 'i18nService', Controller]);

}).call(this);
(function() {
  var Controller;

  Controller = (function() {
    function Controller($scope, $rootScope, $location, entryService, audioService, i18nService) {
      $rootScope.$emit('navigationConfig', {
        labelForTitle: i18nService.get('wordOfTheDayTitle'),
        backAction: function() {
          $location.path('/home');
        }
      });
      $scope.entry = {};
      $scope.listen = function() {
        if ($scope.entry.audio) {
          audioService.play($scope.entry.audio);
        }
      };
      entryService.all().then(function(entries) {
        var index, today;
        today = moment('0', 'hh').unix();
        index = Math.floor(Math.randomWithSeed(today) * entries.length) - 1;
        return $scope.entry = entries[index];
      });
    }

    return Controller;

  })();

  angular.module('app').controller('wordOfTheDayController', ['$scope', '$rootScope', '$location', 'entryService', 'audioService', 'i18nService', Controller]);

}).call(this);
(function() {
  var Service,
    bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

  Service = (function() {
    function Service($q) {
      this.$q = $q;
      this.clear = bind(this.clear, this);
      this.save = bind(this.save, this);
      this.get = bind(this.get, this);
      this.all = bind(this.all, this);
    }

    Service.prototype.all = function() {
      var deferred;
      deferred = this.$q.defer();
      Lawnchair({
        name: 'categories',
        adapter: 'dom'
      }, function(store) {
        return store.all(function(categories) {
          return deferred.resolve(categories.map(function(e) {
            return e.value;
          }));
        });
      });
      return deferred.promise;
    };

    Service.prototype.get = function(categoryId) {
      var deferred;
      deferred = this.$q.defer();
      Lawnchair({
        name: 'categories',
        adapter: 'dom'
      }, function(store) {
        return store.get(categoryId, function(category) {
          return deferred.resolve(category.value);
        });
      });
      return deferred.promise;
    };

    Service.prototype.save = function(category) {
      return Lawnchair({
        name: 'categories',
        adapter: 'dom'
      }, function(store) {
        return store.save({
          key: category.id,
          value: category
        });
      });
    };

    Service.prototype.clear = function() {
      return Lawnchair({
        name: 'categories',
        adapter: 'dom'
      }, function(store) {
        return store.nuke();
      });
    };

    return Service;

  })();

  angular.module('app').service('categoryService', ['$q', Service]);

}).call(this);
(function() {
  var Service,
    bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

  Service = (function() {
    function Service($q) {
      this.$q = $q;
      this.initialSyncCompleted = bind(this.initialSyncCompleted, this);
      this.initialSyncComplete = bind(this.initialSyncComplete, this);
    }

    Service.prototype.initialSyncComplete = function() {
      if (window.localStorage['initialSyncComplete']) {
        return true;
      } else {
        return false;
      }
    };

    Service.prototype.initialSyncCompleted = function() {
      return window.localStorage['initialSyncComplete'] = true;
    };

    return Service;

  })();

  angular.module('app').service('configurationService', ['$q', Service]);

}).call(this);
(function() {
  var Service,
    bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

  Service = (function() {
    function Service($http, $q, categoryService, entryService, fileService) {
      this.$http = $http;
      this.$q = $q;
      this.categoryService = categoryService;
      this.entryService = entryService;
      this.fileService = fileService;
      this.imageTypesFor = bind(this.imageTypesFor, this);
      this.saveAsset = bind(this.saveAsset, this);
      this.saveAssetsForEntry = bind(this.saveAssetsForEntry, this);
      this.saveAssetsForCategory = bind(this.saveAssetsForCategory, this);
    }

    Service.prototype.saveAssetsForCategory = function(category) {
      return this.imageTypesFor(category).forEach((function(_this) {
        return function(imageType) {
          if (category.images[imageType] && category.images[imageType].indexOf('http') === 0) {
            return _this.saveAsset(category.images[imageType]).then(function(dataUri) {
              category.images[imageType] = dataUri;
              return _this.categoryService.save(category);
            });
          }
        };
      })(this));
    };

    Service.prototype.saveAssetsForEntry = function(entry) {
      this.imageTypesFor(entry).forEach((function(_this) {
        return function(imageType) {
          if (entry.images[imageType] && entry.images[imageType].indexOf('http') === 0) {
            return _this.saveAsset(entry.images[imageType]).then(function(dataUri) {
              entry.images[imageType] = dataUri;
              return _this.entryService.save(entry);
            });
          }
        };
      })(this));
      if (entry.audio && entry.audio.indexOf('http') === 0) {
        return this.saveAsset(entry.audio).then((function(_this) {
          return function(dataUri) {
            entry.audio = "" + dataUri;
            return _this.entryService.save(entry);
          };
        })(this));
      }
    };

    Service.prototype.saveAsset = function(url) {
      var deferred, handleError;
      deferred = this.$q.defer();
      handleError = function() {
        console.log("Error saving asset for " + url);
        return deferred.reject();
      };
      this.fileService.existingFor(url).then(function(existingUri) {
        return deferred.resolve(existingUri);
      }, (function(_this) {
        return function() {
          return _this.$http.get(url, {
            responseType: 'arraybuffer'
          }).then(function(res) {
            var blob;
            blob = new Blob([res.data], {
              type: 'text/plain'
            });
            return _this.fileService.store(blob, url).then(function(uri) {
              return deferred.resolve(uri);
            }, handleError);
          }, handleError);
        };
      })(this));
      return deferred.promise;
    };

    Service.prototype.imageTypesFor = function(model) {
      var imageType, imageTypes;
      imageTypes = [];
      for (imageType in model.images) {
        imageTypes.push(imageType);
      }
      return imageTypes;
    };

    return Service;

  })();

  angular.module('app').service('downloadService', ['$http', '$q', 'categoryService', 'entryService', 'fileService', Service]);

}).call(this);
(function() {
  var Service,
    bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

  Service = (function() {
    function Service($q, $analytics) {
      this.$q = $q;
      this.$analytics = $analytics;
      this.clear = bind(this.clear, this);
      this.search_for = bind(this.search_for, this);
      this.save = bind(this.save, this);
      this.entries_for_letter = bind(this.entries_for_letter, this);
      this.all = bind(this.all, this);
      this.get = bind(this.get, this);
      this.entries_for = bind(this.entries_for, this);
    }

    Service.prototype.entries_for = function(categoryId) {
      var deferred;
      deferred = this.$q.defer();
      Lawnchair({
        name: 'entries',
        adapter: 'dom'
      }, (function(_this) {
        return function(store) {
          return store.where("_.contains(record.value.categories, " + categoryId + ")", function(entries) {
            return deferred.resolve(entries.map(function(e) {
              return e.value;
            }));
          });
        };
      })(this));
      return deferred.promise;
    };

    Service.prototype.get = function(entryId) {
      var deferred;
      deferred = this.$q.defer();
      Lawnchair({
        name: 'entries',
        adapter: 'dom'
      }, function(store) {
        return store.get(entryId, function(entry) {
          return deferred.resolve(entry.value);
        });
      });
      return deferred.promise;
    };

    Service.prototype.all = function() {
      var deferred;
      deferred = this.$q.defer();
      Lawnchair({
        name: 'entries',
        adapter: 'dom'
      }, function(store) {
        return store.all(function(entries) {
          return deferred.resolve(entries.map(function(e) {
            return e.value;
          }));
        });
      });
      return deferred.promise;
    };

    Service.prototype.entries_for_letter = function(letter) {
      var deferred;
      deferred = this.$q.defer();
      Lawnchair({
        name: 'entries',
        adapter: 'dom'
      }, function(store) {
        return store.all(function(entry_data) {
          var entries;
          entries = entry_data.map(function(e) {
            return e.value;
          });
          return deferred.resolve(entries.filter(function(e) {
            return e.entry_word[0] === letter;
          }));
        });
      });
      return deferred.promise;
    };

    Service.prototype.save = function(entry) {
      return Lawnchair({
        name: 'entries',
        adapter: 'dom'
      }, function(store) {
        return store.save({
          key: entry.id,
          value: entry
        });
      });
    };

    Service.prototype.search_for = function(query) {
      var deferred;
      deferred = this.$q.defer();
      Lawnchair({
        name: 'entries',
        adapter: 'dom'
      }, (function(_this) {
        return function(store) {
          return store.where("record.value.translation.toLowerCase().indexOf('" + (query.toLowerCase()) + "') !== -1", function(entries) {
            if (entries.length === 0) {
              _this.$analytics.eventTrack('SearchNotFound', {
                category: 'SearchNotFound',
                label: query
              });
            }
            return deferred.resolve(entries.map(function(e) {
              return e.value;
            }));
          });
        };
      })(this));
      return deferred.promise;
    };

    Service.prototype.clear = function() {
      return Lawnchair({
        name: 'entries',
        adapter: 'dom'
      }, function(store) {
        return store.nuke();
      });
    };

    return Service;

  })();

  angular.module('app').service('entryService', ['$q', '$analytics', Service]);

}).call(this);
(function() {
  var Service,
    bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

  Service = (function() {
    function Service($location, $q, categoryService, GAMES_PER_ROUND, LIVES_PER_ROUND) {
      this.$location = $location;
      this.$q = $q;
      this.categoryService = categoryService;
      this.GAMES_PER_ROUND = GAMES_PER_ROUND;
      this.LIVES_PER_ROUND = LIVES_PER_ROUND;
      this.setupGamesFor = bind(this.setupGamesFor, this);
      this.generateGamesListFor = bind(this.generateGamesListFor, this);
      this.gameStatus = bind(this.gameStatus, this);
      this.initialiseStatus = bind(this.initialiseStatus, this);
      this.fail = bind(this.fail, this);
      this.success = bind(this.success, this);
      this.gameInProgress = false;
      this.livesRemaining = 0;
    }

    Service.prototype.success = function() {
      this.lastRoundSuccessful = true;
      return this.gameStatus();
    };

    Service.prototype.fail = function() {
      this.livesRemaining--;
      if (this.livesRemaining === 0) {
        this.gameInProgress = false;
      }
      this.lastRoundSuccessful = false;
      return this.gameStatus();
    };

    Service.prototype.initialiseStatus = function() {
      this.livesLost = 0;
      this.livesRemaining = this.LIVES_PER_ROUND;
      this.gameInProgress = true;
      return this.lastRoundSuccessful = true;
    };

    Service.prototype.gameStatus = function() {
      return {
        livesLost: this.LIVES_PER_ROUND - this.livesRemaining,
        livesRemaining: this.livesRemaining,
        gameInProgress: this.gameInProgress,
        lastRoundSuccessful: this.lastRoundSuccessful
      };
    };

    Service.prototype.generateGamesListFor = function(categoryId) {
      var deferred;
      deferred = this.$q.defer();
      this.categoryService.get(categoryId).then((function(_this) {
        return function(category) {
          var audioGames, games, i, numGamesRemaining, pictureGames, randomGames, results, wordGames;
          wordGames = [6, 7];
          audioGames = [1, 2, 5, 8];
          pictureGames = [3, 4, 9];
          games = wordGames;
          if (category.games.audio) {
            games = games.concat(audioGames);
          }
          if (category.games.image) {
            games = games.concat(pictureGames);
          }
          numGamesRemaining = _this.GAMES_PER_ROUND - games.length;
          randomGames = (function() {
            results = [];
            for (var i = 1; 1 <= numGamesRemaining ? i <= numGamesRemaining : i >= numGamesRemaining; 1 <= numGamesRemaining ? i++ : i--){ results.push(i); }
            return results;
          }).apply(this).map(function(g) {
            var randomIndex;
            randomIndex = Math.floor(Math.random() * (games.length - 1));
            return games[randomIndex];
          });
          games = games.concat(randomGames);
          return deferred.resolve(_.sample(games, _this.GAMES_PER_ROUND));
        };
      })(this));
      return deferred.promise;
    };

    Service.prototype.setupGamesFor = function(categoryId) {
      return this.generateGamesListFor(categoryId).then((function(_this) {
        return function(games) {
          var first_game;
          _this.initialiseStatus();
          first_game = games.pop();
          return _this.$location.path("/games/" + categoryId + "/" + first_game).search("games=" + (JSON.stringify(games)));
        };
      })(this));
    };

    return Service;

  })();

  angular.module('app').service('gameService', ['$location', '$q', 'categoryService', 'GAMES_PER_ROUND', 'LIVES_PER_ROUND', Service]);

}).call(this);
(function() {
  var Service,
    bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

  Service = (function() {
    function Service() {
      this.stop = bind(this.stop, this);
      this.play = bind(this.play, this);
      this.player = $('.player');
      this.player.jPlayer({
        loadeddata: (function(_this) {
          return function(event) {};
        })(this),
        timeupdate: (function(_this) {
          return function(event) {};
        })(this),
        ended: (function(_this) {
          return function(event) {};
        })(this)
      });
    }

    Service.prototype.load = function(file) {
      console.log("Loading " + file);
      return this.player.jPlayer('stop').jPlayer('setMedia', {
        mp3: file,
        m4a: file
      });
    };

    Service.prototype.play = function(file) {
      this.load(file);
      console.log("Playing " + file);
      return this.player.jPlayer('play');
    };

    Service.prototype.stop = function() {
      return this.player.jPlayer('stop');
    };

    return Service;

  })();

  if (!window.isWebView) {
    angular.module('app').service('audioService', [Service]);
  }

}).call(this);
(function() {
  var Service,
    bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

  Service = (function() {
    function Service($q) {
      this.$q = $q;
      this.store = bind(this.store, this);
    }

    Service.prototype.existingFor = function(url) {
      var deferred;
      deferred = this.$q.defer();
      deferred.resolve(url);
      return deferred.promise;
    };

    Service.prototype.store = function(blob, url) {
      var deferred, fileReader;
      deferred = this.$q.defer();
      fileReader = new FileReader();
      fileReader.onload = function(e) {
        return deferred.resolve(e.target.result);
      };
      return deferred.promise;
    };

    return Service;

  })();

  if (!window.isWebView) {
    angular.module('app').service('fileService', ['$q', Service]);
  }

}).call(this);
(function() {
  var EN, Service,
    bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

  EN = {
    homeTitle: 'Jila',
    homeDictionary: 'Dictionary',
    homeCategories: 'Explore',
    homeLearn: 'Learn',
    homeCommon: 'Common Phrases',
    homeWordOfTheDay: 'Word Of The Day',
    homeAbout: 'About',
    homeWarningTitle: 'Warning',
    homeWarningMessage: 'This app may contain images and voices of Aboriginal and Torres Strait Islander people who have passed away',
    categoriesTitle: 'Pick A Category',
    dictionaryTitle: 'Dictionary',
    gamesTitle: 'Pick A Category',
    commonTitle: 'Common Phrases',
    wordOfTheDayTitle: 'Word Of The Day',
    aboutTitle: 'About',
    aboutHistoryTab: 'History',
    aboutResourcesTab: 'Resources',
    aboutLocationTab: 'Location',
    aboutPartnersTab: 'Partners',
    aboutCreditsTab: 'Credits',
    placeholderSearch: 'Search',
    instructionSelectMatch: 'Tap the matching word/phrase',
    instructionMatchPicture: 'Tap the matching picture',
    instructionTranslateAudio: 'Translate what you hear',
    instructionTranslateWord: 'Translate the word/phrase',
    instructionRearrange: 'Re-arrange the tiles to match',
    exitGameConfirmation: 'Are you sure you want to exit? This will end your game',
    placeholderAnswer: 'Type your answer here',
    roundTitleSuccess: 'Congraulations!',
    roundTitleFailure: 'Oh no!',
    roundMessageSuccess: 'You were right!',
    roundMessageSuccessWithWarning: 'Well done, be careful with spelling though',
    roundMessageFailure: 'The correct answer was ',
    sessionTitleSuccess: 'Congratulations!',
    sessionMessageSuccess: 'You\'re on your way!',
    sessionTitleFailure: 'Oh no!',
    sessionMessageFailure: 'You\'ve run out of chances! Better luck next time!',
    acknowledgeButton: 'Ok',
    syncFailureOfflineMessage: 'Unable to update content',
    syncFailureRetryMessage: 'Unable to update content. Check your network connection and retry',
    syncRetryButtonMessage: 'Retry Sync'
  };

  Service = (function() {
    function Service() {
      this.get = bind(this.get, this);
      this.defaultDictionary = EN;
      this.currentDictionary = this.defaultDictionary;
    }

    Service.prototype.get = function(key) {
      return this.currentDictionary[key];
    };

    return Service;

  })();

  angular.module('app').service('i18nService', [Service]);

}).call(this);
(function() {
  var Service,
    bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

  Service = (function() {
    function Service($q) {
      this.$q = $q;
      this.store = bind(this.store, this);
      this.all = bind(this.all, this);
    }

    Service.prototype.all = function() {
      var deferred, storedCredits;
      deferred = this.$q.defer();
      storedCredits = window.localStorage['imageCredits'];
      if (storedCredits) {
        deferred.resolve(JSON.parse(storedCredits));
      }
      return deferred.promise;
    };

    Service.prototype.store = function(imageCredits) {
      window.localStorage['imageCredits'] = JSON.stringify(imageCredits);
    };

    return Service;

  })();

  angular.module('app').service('imageCreditService', ['$q', Service]);

}).call(this);
(function() {
  var Service,
    bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

  Service = (function() {
    function Service() {
      this.stop = bind(this.stop, this);
      this.play = bind(this.play, this);
      this.load = bind(this.load, this);
    }

    Service.prototype.load = function(file) {
      console.log("Loading " + file);
      if (this.media) {
        this.media.stop();
      }
      if (this.media) {
        this.media.release();
      }
      this.media = new Media(file, null, function(e) {
        return console.log(e);
      });
    };

    Service.prototype.play = function(file) {
      console.log("Playing " + file);
      this.load(file);
      return this.media.play();
    };

    Service.prototype.stop = function() {
      if (this.media) {
        this.media.stop();
      }
      if (this.media) {
        return this.media.release();
      }
    };

    return Service;

  })();

  if (window.isWebView) {
    angular.module('app').service('audioService', [Service]);
  }

}).call(this);
(function() {
  var Service,
    bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

  Service = (function() {
    function Service($q) {
      this.$q = $q;
      this.store = bind(this.store, this);
      this.existingFor = bind(this.existingFor, this);
    }

    Service.prototype.filenameFor = function(url) {
      return "" + (url.hashCode());
    };

    Service.prototype.existingFor = function(url) {
      var checkFilePresence, deferred, fileExists, handleError;
      deferred = this.$q.defer();
      handleError = function() {
        return deferred.reject();
      };
      fileExists = function(entry) {
        console.log("Using existing file for " + url + " at " + (entry.toInternalURL()));
        return deferred.resolve(entry.toInternalURL());
      };
      checkFilePresence = (function(_this) {
        return function(fs) {
          return fs.root.getFile('jila/' + _this.filenameFor(url), {
            create: false
          }, fileExists, handleError);
        };
      })(this);
      window.requestFileSystem(LocalFileSystem.PERSISTENT, 0, checkFilePresence, handleError);
      return deferred.promise;
    };

    Service.prototype.store = function(blob, url) {
      var deferred, gotDirectoryEntry, gotFileEntry, gotFileSystem, handleError;
      deferred = this.$q.defer();
      handleError = function() {
        console.log("Error writing file for " + url);
        return deferred.reject();
      };
      gotFileSystem = (function(_this) {
        return function(fs) {
          return fs.root.getDirectory('jila', {
            create: true
          }, gotDirectoryEntry, handleError);
        };
      })(this);
      gotDirectoryEntry = (function(_this) {
        return function(dir) {
          dir.setMetadata((function() {}), handleError, {
            "com.apple.MobileBackup": 1
          });
          return dir.getFile(_this.filenameFor(url), {
            create: true
          }, gotFileEntry, handleError);
        };
      })(this);
      gotFileEntry = function(entry) {
        return entry.createWriter(function(writer) {
          writer.onwriteend = function(e) {
            console.log("Saving " + url + " to " + (entry.toInternalURL()));
            return deferred.resolve(entry.toInternalURL());
          };
          writer.onerror = handleError;
          return writer.write(blob);
        });
      };
      window.requestFileSystem(LocalFileSystem.PERSISTENT, 0, gotFileSystem, handleError);
      return deferred.promise;
    };

    return Service;

  })();

  if (window.isWebView) {
    angular.module('app').service('fileService', ['$q', Service]);
  }

}).call(this);
(function() {
  var Service,
    bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

  Service = (function() {
    function Service(entryService, $q) {
      this.entryService = entryService;
      this.$q = $q;
      this.generateOptionsFor = bind(this.generateOptionsFor, this);
    }

    Service.prototype.generateOptionsFor = function(controller, categoryId) {
      var deferred;
      deferred = this.$q.defer();
      this.entryService.entries_for(categoryId).then(function(allOptions) {
        var displayOptions, options, validOptions;
        validOptions = controller.validOptionsFrom(allOptions);
        displayOptions = controller.displayOptions(validOptions);
        options = _.sample(displayOptions, controller.numOptionsRequired());
        deferred.resolve({
          answer: options[_.random(0, options.length - 1)],
          options: options
        });
      });
      return deferred.promise;
    };

    return Service;

  })();

  angular.module('app').service('optionsGeneratorService', ['entryService', '$q', Service]);

}).call(this);
(function() {
  var Service,
    bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

  Service = (function() {
    function Service($location, gameService, $analytics, i18nService) {
      this.$location = $location;
      this.gameService = gameService;
      this.$analytics = $analytics;
      this.i18nService = i18nService;
      this.handleSubmissionFor = bind(this.handleSubmissionFor, this);
    }

    Service.prototype.handleSubmissionFor = function(controller) {
      var correctImage, explanation, gameStatus, resultTitle, status;
      if (controller.hasValidAnswer()) {
        resultTitle = this.i18nService.get('roundTitleSuccess');
        explanation = this.i18nService.get('roundMessageSuccess');
        gameStatus = this.gameService.success();
      } else if (controller.allowsAcceptableAnswer() && controller.hasAcceptableAnswer()) {
        resultTitle = this.i18nService.get('roundTitleSuccess');
        explanation = this.i18nService.get('roundMessageSuccessWithWarning');
        gameStatus = this.gameService.success();
      } else {
        resultTitle = this.i18nService.get('roundTitleFailure');
        explanation = this.i18nService.get('roundMessageFailure');
        gameStatus = this.gameService.fail();
        if (controller.answerImage) {
          correctImage = controller.answerImage();
        } else {
          explanation = explanation + "'" + controller.$scope.answer.label + "'";
        }
        this.$analytics.eventTrack('IncorrectAnswer', {
          category: 'IncorrectAnswer',
          label: controller.$scope.answer.label
        });
      }
      status = {
        resultTitle: resultTitle,
        explanation: explanation,
        correctImage: correctImage,
        gameStatus: gameStatus
      };
      return this.$location.path("/games/" + (controller.categoryId()) + "/result").search("status=" + (JSON.stringify(status)) + "&games=" + (this.$location.search()['games']));
    };

    return Service;

  })();

  angular.module('app').service('submissionHandlerService', ['$location', 'gameService', '$analytics', 'i18nService', Service]);

}).call(this);
(function() {
  var Service,
    bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

  Service = (function() {
    function Service($http, $q, BACKEND_URL, configurationService, categoryService, entryService, imageCreditService, downloadService) {
      this.$http = $http;
      this.$q = $q;
      this.BACKEND_URL = BACKEND_URL;
      this.configurationService = configurationService;
      this.categoryService = categoryService;
      this.entryService = entryService;
      this.imageCreditService = imageCreditService;
      this.downloadService = downloadService;
      this.refresh = bind(this.refresh, this);
    }

    Service.prototype.refresh = function() {
      var deferred;
      deferred = this.$q.defer();
      this.$http.get(this.BACKEND_URL + "/api/sync/all").then((function(_this) {
        return function(res) {
          _this.categoryService.clear();
          _this.entryService.clear();
          res.data.categories.forEach(function(c) {
            var imageType;
            for (imageType in c.images) {
              if (!c.images[imageType]) {
                c.images[imageType] = "img/missing-category.png";
              }
            }
            _this.categoryService.save(c);
            return _this.downloadService.saveAssetsForCategory(c);
          });
          res.data.entries.forEach(function(e) {
            _this.entryService.save(e);
            return _this.downloadService.saveAssetsForEntry(e);
          });
          _this.imageCreditService.store(res.data.image_credits);
          _this.configurationService.initialSyncCompleted();
          return deferred.resolve();
        };
      })(this), (function(_this) {
        return function(err) {
          return deferred.reject();
        };
      })(this));
      return deferred.promise;
    };

    return Service;

  })();

  angular.module('app').service('syncService', ['$http', '$q', 'BACKEND_URL', 'configurationService', 'categoryService', 'entryService', 'imageCreditService', 'downloadService', Service]);

}).call(this);
(function() {
  angular.module('app').directive("detectBack", [
    '$animate', function($animate) {
      return {
        restrict: "A",
        link: function($scope, $element, attrs) {
          return $element.on('$animate:close', function() {
            if (window.backInProgress > 0) {
              window.backInProgress--;
            }
            if (window.backInProgress === 0) {
              return $('body').removeClass('back');
            }
          });
        }
      };
    }
  ]);

}).call(this);
(function() {
  angular.module('app').directive("focusWhen", function() {
    return {
      restrict: "A",
      scope: {
        focusValue: "=focusWhen"
      },
      link: function($scope, $element, attrs) {
        $scope.$watch("focusValue", function(currentValue, previousValue) {
          if (currentValue === true && !previousValue) {
            $element[0].focus();
          } else {
            if (currentValue === false && previousValue) {
              $element[0].blur();
            }
          }
        });
      }
    };
  });

}).call(this);
(function() {
  angular.module('app').directive("journey", [
    '$timeout', function($timeout) {
      return {
        restrict: "A",
        link: function($scope, $element, attrs) {
          return $scope.$watch('categories', function() {
            var angle, children, distance, dx, dy, height, i, results, track, windowWidth;
            windowWidth = $(window).width();
            height = 100;
            children = $element.children();
            $element.height(children.length * height);
            children.each(function(idx, c) {
              var left, pattern, top, track, xOffset, yOffset;
              c = $(c);
              pattern = idx % 6;
              xOffset = (function() {
                switch (pattern) {
                  case 0:
                    return 10;
                  case 1:
                    return 45;
                  case 2:
                    return 70;
                  case 3:
                    return 35;
                  case 4:
                    return 15;
                  case 5:
                    return 55;
                }
              })();
              left = xOffset / 100 * windowWidth;
              c.css('left', left + "px");
              yOffset = (function() {
                switch (pattern) {
                  case 0:
                    return 8;
                  case 1:
                    return 0;
                  case 2:
                    return 5;
                  case 3:
                    return -25;
                  case 4:
                    return 2;
                  case 5:
                    return 0;
                }
              })();
              top = height * idx + yOffset + height / 2;
              c.css('top', top + "px");
              track = c.find('.track');
              top = left = 0;
              switch (pattern) {
                case 0:
                  left = 90;
                  break;
                case 1:
                  top = 45;
                  left = 45;
                  break;
                case 2:
                  left = -45;
                  break;
                case 3:
                  top = 45;
                  break;
                case 4:
                  left = 90;
                  break;
                case 5:
                  left = -90;
              }
              track.css('top', top + "px");
              return track.css('left', left + "px");
            });
            i = 0;
            results = [];
            while (i < children.length - 1) {
              track = $(children[i]).find('.track');
              dx = children[i].offsetLeft - children[i + 1].offsetLeft;
              dy = children[i].offsetTop - children[i + 1].offsetTop;
              angle = Math.atan2(dy, dx) * 180 / Math.PI + 270;
              track.css('transform', "rotate(" + angle + "deg)");
              distance = Math.sqrt(Math.pow(dx, 2) + Math.pow(dy, 2));
              track.height(distance);
              results.push(i++);
            }
            return results;
          });
        }
      };
    }
  ]);

}).call(this);
(function() {
  angular.module('app').directive("detectKeyboard", [
    function() {
      return {
        restrict: "A",
        link: function($scope, $element, attrs) {
          var targetElement;
          targetElement = $('body');
          return $scope.$on('$viewContentLoaded', function() {
            $('input,textarea').on('focus', function() {
              return targetElement.addClass('keyboard-visible');
            });
            return $('input,textarea').on('blur', function() {
              return targetElement.removeClass('keyboard-visible');
            });
          });
        }
      };
    }
  ]);

}).call(this);
(function() {
  angular.module('app').directive("detectOs", [
    function() {
      return {
        restrict: "A",
        link: function($scope, $element, attrs) {
          var isAndroid, isIOS, versionNumber;
          isIOS = /iPhone|iPad|iPod/i.test(navigator.userAgent);
          if (isIOS) {
            $element.addClass('ios');
            versionNumber = parseFloat(navigator.userAgent.match(/OS \d/)[0][3]);
            if (versionNumber >= 7) {
              $element.addClass('ios7');
            }
          }
          isAndroid = /Android/i.test(navigator.userAgent);
          if (isAndroid) {
            $element.addClass('android');
            versionNumber = parseFloat(navigator.userAgent.match(/Android (\d+(?:\.\d+)+)/)[1]);
            if (versionNumber < 4.4) {
              return $element.addClass('old-android');
            }
          }
        }
      };
    }
  ]);

}).call(this);
(function() {
  angular.module('app').directive("scaleFit", [
    '$timeout', function($timeout) {
      return {
        restrict: "A",
        link: function($scope, $element, attrs) {
          var maxWidth;
          maxWidth = $element.innerWidth();
          if (attrs.scaleFit) {
            maxWidth = attrs.scaleFit;
          }
          return $timeout(function() {
            var childSpan, difference, scale, spanWidth;
            $element.css('white-space', 'nowrap');
            childSpan = $element.find('span');
            spanWidth = childSpan.innerWidth();
            if (spanWidth > maxWidth) {
              scale = maxWidth / spanWidth;
              difference = (spanWidth - spanWidth * scale) / 2;
              childSpan.css('display', 'inline-block');
              childSpan.css('transform-origin', 'left');
              childSpan.css('transform', "scale(" + scale + ")");
              childSpan.innerWidth(maxWidth + "px");
            }
          }, 100);
        }
      };
    }
  ]);

}).call(this);
(function() {
  angular.module('app').directive("slickCarousel", function() {
    return {
      restrict: "A",
      link: function($scope, $element, attrs) {
        $scope.content = $element.slick({
          arrows: false,
          infinite: false,
          onAfterChange: function(state) {
            return $scope.$apply(function() {
              $scope.indexChanged(state.currentSlide);
            });
          }
        });
        return setTimeout(function() {
          var newHeight;
          newHeight = $(window).height() - $('.navigation').height() - $('.tab-headers').height();
          return $element.find('.tab-page').height(newHeight);
        });
      }
    };
  });

}).call(this);
(function() {
  angular.module('app').directive("slip", function() {
    return {
      restrict: "A",
      require: '?ngModel',
      link: function($scope, $element, attrs, ngModel) {
        var list;
        list = $element[0];
        list.addEventListener('slip:beforewait', function(e) {
          return e.preventDefault();
        });
        list.addEventListener('slip:reorder', function(e) {
          e.target.parentNode.insertBefore(e.target, e.detail.insertBefore);
          return $scope.$apply(function() {
            return ngModel.$modelValue.splice(e.detail.spliceIndex, 0, ngModel.$modelValue.splice(e.detail.originalIndex, 1)[0]);
          });
        });
        return new Slip(list);
      }
    };
  });

}).call(this);
(function() {
  $(function() {
    return angular.bootstrap(document, ['app']);
  });

}).call(this);
