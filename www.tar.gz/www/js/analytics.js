(function() {
  Platform.isReady(function() {
    var trackingID;
    trackingID = '<insert tracking ID here>';
    if (window.isWebView) {
      ga('create', trackingID, {
        'storage': 'none',
        'clientId': device.uuid
      });
      return ga('set', 'checkProtocolTask', null);
    } else {
      return ga('create', trackingID, 'auto');
    }
  });

}).call(this);
