(function() {
  if (typeof Math.randomWithSeed === 'undefined') {
    Math.randomWithSeed = function(seed) {
      var x;
      x = Math.sin(seed) * 10000;
      return x - Math.floor(x);
    };
  }

}).call(this);
